#!/usr/bin/env node
// riP - Discord whitelist bot with a signed key API and a Lua loader.
// run: node src/index.mjs
// env: see .env.example; a .env beside the project is loaded if present.

import {
  Client, GatewayIntentBits, MessageFlags, REST, Routes, SlashCommandBuilder,
  EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder,
  TextInputBuilder, TextInputStyle, StringSelectMenuBuilder, PermissionFlagsBits,
  ChannelType,
} from "discord.js";
import { createServer } from "node:http";
import {
  randomBytes, createHmac, createHash, timingSafeEqual,
} from "node:crypto";
import { existsSync, mkdirSync, readFileSync, writeFileSync, renameSync } from "node:fs";
import { dirname } from "node:path";
import { pathToFileURL } from "node:url";

try { process.loadEnvFile?.(); } catch { /* no .env */ }

const env = (k, d) => process.env[k] ?? d;
const CONFIG = {
  token: env("DISCORD_TOKEN"),
  clientId: env("DISCORD_CLIENT_ID"),
  guildId: env("DISCORD_GUILD_ID") || null,
  apiSecret: env("API_SECRET", randomBytes(32).toString("hex")),
  adminSecret: env("ADMIN_SECRET", randomBytes(16).toString("hex")),
  port: Number(env("API_PORT", 8080)),
  publicBase: env("PUBLIC_BASE_URL", "http://127.0.0.1:8080").replace(/\/$/, ""),
  dbPath: env("DB_PATH", "data/keygate.json"),
  ownerIds: env("OWNER_IDS", "").split(",").map((s) => s.trim()).filter(Boolean),
  ticketTtl: Number(env("TICKET_TTL", 120)),
  webSecret: env("WEB_SECRET", ""),
  rateLimit: Math.max(10, Number(env("RATE_LIMIT", 60)) || 60),
  // Off unless a reverse proxy sets x-forwarded-for. Trusting the header while
  // directly exposed lets anyone rotate the value and dodge the rate limit.
  trustProxy: env("TRUST_PROXY", "") === "1",
};
const now = () => Math.floor(Date.now() / 1000);

/* ---------------------------------------------------------------- storage */

const empty = () => ({
  guilds: {}, scripts: {}, keys: {}, panels: {}, tickets: {}, giveaways: {},
  executions: [], audit: [],
});
let data = empty();
if (existsSync(CONFIG.dbPath)) {
  try { data = { ...empty(), ...JSON.parse(readFileSync(CONFIG.dbPath, "utf8")) }; }
  catch { console.error("store unreadable, starting empty"); }
}

let saveTimer = null;
function flush() {
  mkdirSync(dirname(CONFIG.dbPath), { recursive: true });
  const tmp = `${CONFIG.dbPath}.tmp`;
  writeFileSync(tmp, JSON.stringify(data));
  renameSync(tmp, CONFIG.dbPath);
}
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => { saveTimer = null; try { flush(); } catch (e) { console.error("save failed", e.message); } }, 150);
}

const guildDefaults = (id) => ({
  id, logs_webhook: null, panel_text: null,
  manager_role: null, buyer_role: null, auto_role: null, ticket_category: null,
  hwid_reset_days: 7, created_at: now(),
  welcome_channel: null, welcome_text: null, mod_log_channel: null,
  verify_role: null, raid_mode: "off", join_limit: 8, join_window: 60,
  min_account_days: 0, lockdown: false,
});

function getGuild(id) {
  if (!data.guilds[id]) {
    data.guilds[id] = guildDefaults(id);
    save();
  }
  return data.guilds[id];
}

// Read-only guild view. Cooldown checks run on the hot path of every key check;
// a read there must not create a row (and a disk write) as a side effect.
const peekGuild = (id) => data.guilds[id] || guildDefaults(id);

const GUILD_FIELDS = ["logs_webhook", "panel_text", "manager_role", "buyer_role", "auto_role", "ticket_category", "hwid_reset_days",
  "welcome_channel", "welcome_text", "mod_log_channel", "verify_role", "raid_mode", "join_limit", "join_window", "min_account_days", "lockdown"];
function setGuild(id, patch) {
  const guild = getGuild(id);
  for (const field of GUILD_FIELDS) if (field in patch) guild[field] = patch[field];
  save();
  return guild;
}

// Keys issued before the RIP_ prefix existed are still 32 letters. Both shapes
// resolve to the same store row, so old buyers are not locked out by a rename.
const KEY_BODY = "[a-zA-Z]{32}";
const KEY_RE = new RegExp(`^(?:RIP_)?${KEY_BODY}$`);
const isKeyShape = (value) => typeof value === "string" && KEY_RE.test(value.trim());
const normalizeKey = (value) => String(value || "").trim();

// A buyer may type the prefix on a legacy key or omit it on a new one. Every
// lookup tries both spellings against the store instead of guessing which era
// the key came from.
function keyVariants(value) {
  const raw = normalizeKey(value);
  if (!raw) return [];
  const bare = raw.replace(/^RIP_/i, "");
  return raw.startsWith("RIP_") ? [raw, bare] : [raw, `RIP_${bare}`];
}

function getKey(value) {
  for (const candidate of keyVariants(value)) {
    if (data.keys[candidate]) return data.keys[candidate];
  }
  return null;
}

/* ------------------------------------------------------------------ audit */

// Every staff mutation lands here. It is the only durable trail of who changed
// what, so it is capped but never sampled, and mirrored to the log webhook.
function audit(guild, actor, action, detail = "") {
  if (!Array.isArray(data.audit)) data.audit = [];
  const entry = {
    at: now(), guild_id: guild?.id || null,
    actor_id: actor?.id || null, actor_tag: actor?.tag || null,
    action, detail: String(detail).slice(0, 300),
  };
  data.audit.push(entry);
  if (data.audit.length > 5000) data.audit.splice(0, data.audit.length - 5000);
  save();
  if (guild?.logs_webhook) {
    alert(guild, `staff **${action}** by <@${entry.actor_id}>${entry.detail ? ` - ${entry.detail}` : ""}`);
  }
  return entry;
}

/* ----------------------------------------------------------------- tickets */

function openTicket(guildId, channelId, userId) {
  data.tickets[channelId] = {
    guild_id: guildId, channel_id: channelId, user_id: userId,
    opened_at: now(), closed_at: null, closed_by: null, open: true,
  };
  save();
  return data.tickets[channelId];
}

function closeTicket(channelId, closedBy) {
  const ticket = data.tickets[channelId];
  if (!ticket || !ticket.open) return null;
  ticket.open = false;
  ticket.closed_at = now();
  ticket.closed_by = closedBy;
  save();
  return ticket;
}

const isTicketChannel = (channelId) => Boolean(data.tickets[channelId]?.open);

/* ---------------------------------------------------------------- giveaways */

let botClient = null;

const giveawayEmbed = (giveaway) =>
  new EmbedBuilder()
    .setTitle(`Giveaway - ${giveaway.prize}`)
    .setColor(0xfee75c)
    .addFields(
      { name: "Winners", value: String(giveaway.winners), inline: true },
      { name: "Entries", value: String(giveaway.entries.length), inline: true },
      { name: "Ends", value: `<t:${giveaway.ends_at}:R>`, inline: true },
    )
    .setFooter({ text: "Press Enter - one entry per person." });

function drawGiveaway(id) {
  const giveaway = data.giveaways?.[id];
  if (!giveaway || giveaway.ended) return null;
  giveaway.ended = true;
  giveaway.ended_at = now();

  const pool = [...new Set(giveaway.entries)];
  for (let i = pool.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  const winners = pool.slice(0, Math.min(giveaway.winners, pool.length));
  giveaway.winner_ids = winners;
  const keys = createKeys({
    guildId: giveaway.guild_id,
    count: giveaway.winners,
    days: giveaway.days || 0,
    note: `giveaway: ${giveaway.prize}`,
  });
  save();

  for (let i = 0; i < winners.length; i += 1) {
    const userId = winners[i];
    const key = keys[i] || keys[0];
    if (!botClient) continue;
    botClient.users.fetch(userId)
      .then((user) => user.send({
        embeds: [new EmbedBuilder().setTitle("You won").setColor(0x57f287)
          .setDescription(`**${giveaway.prize}**\nYour key:\n\`\`\`\n${key}\n\`\`\``)],
      }))
      .catch(() => {});
  }
  return { winners, keys };
}

async function finishGiveaway(id) {
  const giveaway = data.giveaways?.[id];
  const result = drawGiveaway(id);
  if (!giveaway || !result) return;
  if (!botClient) return;
  const channel = await botClient.channels.fetch(giveaway.channel_id).catch(() => null);
  const message = channel ? await channel.messages.fetch(giveaway.message_id).catch(() => null) : null;
  if (!message) return;
  await message.edit({
    embeds: [giveawayEmbed(giveaway)
      .setColor(result.winners.length ? 0x57f287 : 0xed4245)
      .setFooter({ text: result.winners.length ? "Winners drawn - keys sent by DM" : "No entries, nobody won" })],
    components: [],
  }).catch(() => {});
}

/* ------------------------------------------------------------- primitives */

const ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

// 52 letters * 4 = 208: bytes at or above it are rejected so the modulo is unbiased.
function newKey(length = 32) {
  const out = [];
  while (out.length < length) {
    for (const byte of randomBytes(length)) {
      if (byte >= 208) continue;
      out.push(ALPHABET[byte % 52]);
      if (out.length === length) break;
    }
  }
  return out.join("");
}

const hwidHash = (hwid) => createHash("sha256").update(String(hwid)).digest("hex").slice(0, 32);
// IPs are kept as a short keyed-free digest: enough to spot one machine hammering
// many keys, useless for identifying a person from the store alone.
const hashIpAddress = (ip) => createHash("sha256").update(`ip:${String(ip)}`).digest("hex").slice(0, 12);
const sign = (payload) => createHmac("sha256", CONFIG.apiSecret).update(String(payload)).digest("hex");

function safeEqual(a, b) {
  const left = Buffer.from(String(a));
  const right = Buffer.from(String(b));
  if (left.length !== right.length) return false;
  return timingSafeEqual(left, right);
}

/* ---------------------------------------------------------------- service */

const CODE = {
  VALID: "KEY_VALID", EXPIRED: "KEY_EXPIRED", BANNED: "KEY_BANNED",
  HWID_LOCKED: "KEY_HWID_LOCKED", INCORRECT: "KEY_INCORRECT", INVALID: "KEY_INVALID",
  SCRIPT: "SCRIPT_ID_INCORRECT", RATE: "RATE_LIMITED",
};

const MESSAGE = {
  KEY_VALID: "The provided key is valid.",
  KEY_EXPIRED: "The provided key has expired.",
  KEY_BANNED: "The provided key is blacklisted.",
  KEY_HWID_LOCKED: "Key is locked to a different device. Reset your HWID.",
  KEY_INCORRECT: "The provided key is incorrect.",
  KEY_INVALID: "The provided key has an invalid format.",
  SCRIPT_ID_INCORRECT: "The provided script ID is incorrect.",
  RATE_LIMITED: "Too many requests.",
};

const fail = (code) => ({ code, message: MESSAGE[code] });

function record(key, scriptId, allowed, reason, ip) {
  data.executions.push({
    key, scriptId, allowed: allowed ? 1 : 0, reason,
    ip: ip ? hashIpAddress(ip) : null, at: now(),
  });
  if (data.executions.length > 20000) data.executions.splice(0, data.executions.length - 20000);
  save();
}

function createKeys({ guildId, scriptId = null, count = 1, days = 0, note = null, discordId = null }) {
  const total = Math.max(1, Math.min(500, Math.trunc(Number(count)) || 1));
  const expiresAt = days > 0 ? now() + Math.trunc(days) * 86400 : 0;
  const issued = [];
  for (let i = 0; i < total; i += 1) {
    let key;
    do { key = `RIP_${newKey(32)}`; } while (data.keys[key]);
    data.keys[key] = {
      key, guild_id: guildId, script_id: scriptId, discord_id: discordId, note,
      created_at: now(), expires_at: expiresAt, hwid: null, hwid_reset_at: 0,
      banned: 0, ban_reason: null, executions: 0, redeemed_at: null,
      last_seen_at: 0, last_ip: null,
    };
    issued.push(key);
  }
  save();
  return issued;
}

function checkKey({ key, scriptId = null, hwid = null, ip = null }) {
  const value = normalizeKey(key);
  if (!isKeyShape(value)) return fail(CODE.INVALID);
  const row = getKey(value);
  if (!row) { record(value, scriptId, false, "unknown key", ip); return fail(CODE.INCORRECT); }
  if (row.banned) { record(value, scriptId, false, "banned", ip); return fail(CODE.BANNED); }
  if (scriptId && row.script_id && row.script_id !== scriptId) {
    record(value, scriptId, false, "script mismatch", ip);
    return fail(CODE.SCRIPT);
  }
  if (row.expires_at > 0 && row.expires_at <= now()) {
    record(value, scriptId, false, "expired", ip);
    return fail(CODE.EXPIRED);
  }
  const hash = hwid ? hwidHash(hwid) : null;
  if (row.hwid && hash && row.hwid !== hash) {
    record(value, scriptId, false, "hwid mismatch", ip);
    return fail(CODE.HWID_LOCKED);
  }
  if (!row.hwid && hash) { row.hwid = hash; row.hwid_reset_at = now(); }
  row.executions = (row.executions || 0) + 1;
  row.last_seen_at = now();
  if (ip) row.last_ip = hashIpAddress(ip);
  save();
  record(value, scriptId, true, "valid", ip);
  return {
    code: CODE.VALID,
    message: MESSAGE.KEY_VALID,
    data: {
      auth_expire: row.expires_at,
      note: row.note || "Not specified",
      total_executions: row.executions,
      hwid_locked: Boolean(row.hwid),
    },
  };
}

function signed(result, key) {
  const time = now();
  return { ...result, time, signature: sign(`${key}|${result.code}|${time}`) };
}

function cooldownRemaining(row, guildId = null) {
  if (!row) return 0;
  const guild = peekGuild(guildId || row.guild_id);
  const cooldown = guild.hwid_reset_days * 86400;
  if (cooldown <= 0) return 0;
  const left = row.hwid_reset_at + cooldown - now();
  return left > 0 ? left : 0;
}

function resetHwid(key, { force = false, guildId = null } = {}) {
  const row = getKey(key);
  if (!row) return { ok: false, error: "key not found" };
  if (!force) {
    const left = cooldownRemaining(row, guildId);
    if (left > 0) {
      const hours = Math.ceil(left / 3600);
      return { ok: false, error: `cooldown active, ${hours}h left`, cooldownSeconds: left };
    }
  }
  row.hwid = null;
  row.hwid_reset_at = now();
  save();
  const guild = peekGuild(guildId || row.guild_id);
  return { ok: true, nextResetAt: guild.hwid_reset_days > 0 ? row.hwid_reset_at + guild.hwid_reset_days * 86400 : 0 };
}

function changeDays(key, days, mode = "add") {
  const row = getKey(key);
  if (!row) return { ok: false, error: "key not found" };
  const span = Math.max(1, Math.min(3650, Math.trunc(days))) * 86400;
  row.expires_at = mode === "set" ? now() + span : (row.expires_at > 0 ? row.expires_at : now()) + span;
  save();
  return { ok: true, expiresAt: row.expires_at };
}

function revoke(key) {
  if (!data.keys[key]) return false;
  delete data.keys[key];
  save();
  return true;
}

function ban(key, { reason = null, days = 0 } = {}) {
  const row = getKey(key);
  if (!row) return { ok: false, error: "key not found" };
  row.banned = 1;
  row.ban_reason = reason;
  if (days > 0) row.expires_at = now() + Math.trunc(days) * 86400;
  save();
  return { ok: true };
}

// A key is redeemed exactly once. The first Discord account to claim it owns it
// until staff unbind it; everyone after that is refused, not silently rebound.
function bindDiscord(key, discordId) {
  const value = normalizeKey(key);
  if (!isKeyShape(value)) {
    return { ok: false, error: "That key does not look right. Keys are RIP_ plus 32 letters." };
  }
  const row = getKey(value);
  if (!row) return { ok: false, error: "That key does not exist." };
  if (row.banned) return { ok: false, error: "That key is blacklisted." };
  if (row.expires_at > 0 && row.expires_at <= now()) return { ok: false, error: "That key has expired." };
  if (row.discord_id === discordId) return { ok: true, already: true, row };
  if (row.discord_id) return { ok: false, error: "That key is already redeemed by another account." };

  row.discord_id = discordId;
  row.redeemed_at = now();
  save();
  return { ok: true, already: false, row };
}

function keyForDiscord(discordId, guildId) {
  const rows = Object.values(data.keys).filter((k) => k.discord_id === discordId && k.guild_id === guildId);
  return rows.sort((a, b) => b.created_at - a.created_at)[0] || null;
}

function stats(guildId) {
  const rows = Object.values(data.keys).filter((k) => k.guild_id === guildId);
  return {
    total: rows.length,
    expired: rows.filter((k) => k.expires_at > 0 && k.expires_at <= now()).length,
    banned: rows.filter((k) => k.banned).length,
    executions: rows.reduce((sum, k) => sum + k.executions, 0),
  };
}

/* --------------------------------------------------- tickets and monitoring */

// Short-lived proof that a check passed. The loader trades a ticket for the
// script body, so the key is not replayed on every asset fetch and a leaked
// loader URL dies within two minutes.
function issueTicket(key, scriptId) {
  const expires = now() + CONFIG.ticketTtl;
  return `${key}.${expires}.${sign(`${key}|${scriptId}|${expires}`)}`;
}

function verifyTicket(ticket, scriptId) {
  const parts = String(ticket || "").split(".");
  if (parts.length !== 3) return null;
  const [key, expiresRaw, mac] = parts;
  const expires = Number(expiresRaw);
  if (!Number.isFinite(expires) || expires < now()) return null;
  if (!safeEqual(mac, sign(`${key}|${scriptId}|${expires}`))) return null;
  const row = getKey(key);
  if (!row || row.banned) return null;
  if (row.expires_at > 0 && row.expires_at <= now()) return null;
  if (row.script_id && row.script_id !== scriptId) return null;
  return row;
}

const metrics = { started: now(), checks: 0, valid: 0, denied: 0, loader: 0 };

/* --------------------------------------------------------------- raidshield */

const joins = new Map();

// Sliding join window per guild. Cheap, local, no external service: a burst
// above join_limit inside join_window trips the shield or locks the guild down.
function recordJoin(guildId) {
  const cfg = peekGuild(guildId);
  const stamp = Date.now();
  const windowMs = Math.max(10, Number(cfg.join_window) || 60) * 1000;
  const bucket = (joins.get(guildId) || []).filter((t) => stamp - t < windowMs);
  bucket.push(stamp);
  joins.set(guildId, bucket);
  return bucket.length >= Math.max(2, Number(cfg.join_limit) || 8);
}

// Runs before any role is granted. Strict mode kicks on a burst or on an
// account younger than min_account_days; smart mode locks the guild and alerts.
async function raidShield(member, cfg) {
  if (!cfg || cfg.raid_mode === "off") return;
  const burst = recordJoin(member.guild.id);
  const ageDays = (Date.now() - member.user.createdTimestamp) / 86400000;
  const tooNew = cfg.min_account_days > 0 && ageDays < cfg.min_account_days;

  if (cfg.raid_mode === "strict" && (burst || tooNew)) {
    await member.kick("raid shield").catch(() => {});
    await alert(cfg, `raid shield kicked ${member.user.tag}`);
    return;
  }
  if (burst && !cfg.lockdown) {
    setGuild(member.guild.id, { lockdown: true });
    await alert(cfg, `raid shield tripped: ${cfg.join_limit} joins / ${cfg.join_window}s - locked down`);
  }
  if (tooNew) await member.kick("raid shield: account too new").catch(() => {});
}


const alertAt = new Map();

// Alerts are best effort and throttled: a webhook outage must never fail a check.
async function alert(guild, text) {
  if (!guild?.logs_webhook) return;
  if (now() - (alertAt.get(guild.id) || 0) < 10) return;
  alertAt.set(guild.id, now());
  try {
    await fetch(guild.logs_webhook, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: "riP", content: text.slice(0, 1800) }),
      signal: AbortSignal.timeout(5000),
    });
  } catch { /* logged nowhere on purpose: a dead webhook is not a security event */ }
}

/* ---------------------------------------------------------------- http api */

const buckets = new Map();
let lastPrune = 0;

// Rolling window per client. The sweep keeps the map bounded without the old
// clear-everything behaviour, which handed every abuser a fresh allowance.
function allow(ip, max = CONFIG.rateLimit, windowMs = 60_000) {
  const stamp = Date.now();
  if (stamp - lastPrune > 120_000) {
    lastPrune = stamp;
    for (const [client, bucket] of buckets) {
      if (stamp - bucket.start > windowMs * 2) buckets.delete(client);
    }
  }
  const bucket = buckets.get(ip);
  if (!bucket || stamp - bucket.start > windowMs) {
    buckets.set(ip, { start: stamp, count: 1 });
    return true;
  }
  bucket.count += 1;
  return bucket.count <= max;
}

function clientIp(req) {
  if (CONFIG.trustProxy) {
    const forwarded = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim();
    if (forwarded) return forwarded;
  }
  return req.socket?.remoteAddress || "0";
}

function send(res, status, body, type = "application/json") {
  const payload = type === "application/json" ? JSON.stringify(body) : String(body);
  res.writeHead(status, { "content-type": type, "cache-control": "no-store" });
  res.end(payload);
}

async function readBody(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 16384) throw new Error("body too large");
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString("utf8")); } catch { return {}; }
}

function maskId(id) {
  const value = String(id || "");
  if (!value) return null;
  return `${"*".repeat(Math.max(0, value.length - 4))}${value.slice(-4)}`;
}

// Enough of a key to recognise an activity row on the public dashboard without
// publishing a working credential.
function maskKey(key) {
  const value = String(key || "");
  if (value.length < 10) return "...";
  return `${value.slice(0, 4)}...${value.slice(-4)}`;
}

// Shape the site sees. The Discord id is masked by default: knowing a key should
// not hand out the account behind it.
function publicRow(row) {
  if (!row) return null;
  return {
    ok: true,
    key: row.key,
    banned: Boolean(row.banned),
    banReason: row.ban_reason || null,
    expiresAt: row.expires_at || 0,
    createdAt: row.created_at || 0,
    bound: Boolean(row.hwid),
    discordId: maskId(row.discord_id),
    note: row.note || null,
    executions: row.executions || 0,
    lastSeenAt: row.last_seen_at || 0,
    scriptId: row.script_id || null,
    cooldownSeconds: cooldownRemaining(row),
  };
}

function startApi() {
  const server = createServer(async (req, res) => {
    const url = new URL(req.url, "http://localhost");
    const ip = clientIp(req);

    if (url.pathname === "/v1/health") return send(res, 200, { ok: true, time: now() });
    if (url.pathname === "/v1/sync") {
      return send(res, 200, { st: now(), cf: "RIP", nodes: [`${CONFIG.publicBase}/v1/`] });
    }

    // Some executors only POST; both shapes feed the same service call.
    if (url.pathname === "/v1/check") {
      const body = req.method === "POST" ? await readBody(req) : {};
      const key = normalizeKey(body.key ?? url.searchParams.get("key"));
      if (!allow(ip)) return send(res, 429, signed({ code: CODE.RATE, message: MESSAGE.RATE_LIMITED }, key));

      // A key bound to one script can omit script_id; the store answers for it.
      const row = getKey(key);
      const requestedScript = String(body.script_id ?? url.searchParams.get("script_id") ?? "").trim();
      const scriptId = requestedScript || row?.script_id || "";
      const hwid = String(
        req.headers["x-hwid"] || req.headers.clienthwid
        || url.searchParams.get("hwid") || body.hwid || "",
      );
      if (!hwid) return send(res, 400, signed({ code: CODE.INVALID, message: "Missing HWID header." }, key));
      if (!isKeyShape(key)) return send(res, 400, signed({ code: CODE.INVALID, message: MESSAGE.KEY_INVALID }, key));
      if (!scriptId) return send(res, 400, signed({ code: CODE.SCRIPT, message: "Missing script_id." }, key));
      if (!data.scripts[scriptId]) return send(res, 404, signed({ code: CODE.SCRIPT, message: MESSAGE.SCRIPT_ID_INCORRECT }, key));

      metrics.checks += 1;
      const result = checkKey({ key, scriptId, hwid, ip });
      if (result.code === CODE.VALID) {
        metrics.valid += 1;
        result.data.ticket = issueTicket(key, scriptId || "*");
      } else {
        metrics.denied += 1;
        const row = getKey(key);
        if (row) alert(getGuild(row.guild_id), `refused **${result.code}** on \`${scriptId || "any"}\` from \`${hashIpAddress(ip)}\``);
      }
      return send(res, 200, signed(result, key));
    }

    if (url.pathname === "/v1/metrics") {
      const day = now() - 86400;
      return send(res, 200, {
        ...metrics,
        uptime: now() - metrics.started,
        keys: Object.keys(data.keys).length,
        guilds: Object.keys(data.guilds).length,
        scripts: Object.keys(data.scripts).length,
        checks24h: data.executions.filter((entry) => entry.at > day).length,
      });
    }

    if (url.pathname.startsWith("/v1/loader/")) {
      return send(res, 410, 'error("loader hosting removed; publish your own and point it at /v1/check")', "text/plain");
    }

    if (url.pathname === "/v1/resethwid" && req.method === "POST") {
      if (!safeEqual(req.headers["x-admin-secret"] || "", CONFIG.adminSecret)) {
        return send(res, 403, { ok: false, error: "forbidden" });
      }
      const body = await readBody(req);
      if (!body.key) return send(res, 400, { ok: false, error: "key required" });
      return send(res, 200, resetHwid(String(body.key), { force: Boolean(body.force) }));
    }

    if (url.pathname.startsWith("/v1/web/")) {
      if (!CONFIG.webSecret) return send(res, 503, { error: "web api disabled - set WEB_SECRET on the bot" });
      if (!safeEqual(req.headers["x-web-secret"] || "", CONFIG.webSecret)) {
        return send(res, 403, { error: "forbidden" });
      }
      if (!allow(ip)) return send(res, 429, { error: "slow down" });

      const body = req.method === "POST" ? await readBody(req) : {};
      const key = normalizeKey(body.key || url.searchParams.get("key") || "");

      if (url.pathname === "/v1/web/stats") {
        const rows = Object.values(data.keys);
        const stamp = now();
        return send(res, 200, {
          keys: rows.length,
          keysActive: rows.filter((k) => !k.banned && (k.expires_at === 0 || k.expires_at > stamp)).length,
          keysExpired: rows.filter((k) => k.expires_at > 0 && k.expires_at <= stamp).length,
          keysBanned: rows.filter((k) => k.banned).length,
          guilds: Object.keys(data.guilds).length,
          scripts: Object.keys(data.scripts).length,
          served: metrics.checks,
          valid: metrics.valid,
          denied: metrics.denied,
          uptime: stamp - metrics.started,
          checks24h: data.executions.filter((entry) => entry.at > stamp - 86400).length,
          executions: rows.reduce((sum, k) => sum + (k.executions || 0), 0),
          // The landing page renders this feed. Keys are masked: a public stats
          // endpoint must never hand out a credential.
          recent: data.executions.slice(-8).reverse().map((entry) => ({
            at: entry.at,
            allowed: Boolean(entry.allowed),
            reason: entry.reason,
            scriptId: entry.scriptId,
            key: maskKey(entry.key),
          })),
          scriptList: Object.values(data.scripts).map((s) => ({
            id: s.script_id, hasUrl: isHttpUrl(s.script_url),
          })),
        });
      }

      if (url.pathname === "/v1/web/redeem" && req.method === "POST") {
        const discordId = String(body.discordId || "").replace(/\D/g, "");
        if (!discordId) return send(res, 400, { ok: false, error: "discord id required" });
        const result = bindDiscord(key, discordId);
        return send(res, result.ok ? 200 : 400, result.ok
          ? { ok: true, already: Boolean(result.already), row: publicRow(result.row) }
          : { ok: false, error: result.error });
      }

      if (url.pathname === "/v1/web/key") {
        const row = getKey(key);
        if (!row) return send(res, 404, { ok: false, error: "key not found" });
        return send(res, 200, publicRow(row));
      }

      if (url.pathname === "/v1/web/mykey") {
        const discordId = String(body.discordId || url.searchParams.get("discordId") || "").replace(/\D/g, "");
        if (!discordId) return send(res, 400, { ok: false, error: "discord id required" });
        const rows = Object.values(data.keys)
          .filter((row) => row.discord_id === discordId)
          .sort((a, b) => (b.created_at || 0) - (a.created_at || 0));
        if (!rows.length) return send(res, 404, { ok: false, error: "no key linked to that account" });
        return send(res, 200, { ok: true, keys: rows.slice(0, 10).map(publicRow) });
      }

      if (url.pathname === "/v1/web/history") {
        const row = getKey(key);
        if (!row) return send(res, 404, { ok: false, error: "key not found" });
        const entries = data.executions
          .filter((entry) => entry.key === row.key)
          .slice(-10)
          .reverse()
          .map((entry) => ({ at: entry.at, allowed: Boolean(entry.allowed), reason: entry.reason, scriptId: entry.scriptId }));
        return send(res, 200, { ok: true, executions: entries });
      }

      if (url.pathname === "/v1/web/scripts") {
        return send(res, 200, {
          ok: true,
          scripts: Object.values(data.scripts).map((s) => ({
            id: s.script_id, guildId: s.guild_id, hasUrl: isHttpUrl(s.script_url),
          })),
        });
      }

      // Hands the site the same guard the Discord panel builds, so a buyer can
      // copy their loader without leaving the browser.
      if (url.pathname === "/v1/web/loader" && req.method === "POST") {
        const row = getKey(key);
        if (!row) return send(res, 404, { ok: false, error: "key not found" });
        if (row.banned) return send(res, 403, { ok: false, error: "key is blacklisted" });
        if (row.expires_at > 0 && row.expires_at <= now()) {
          return send(res, 403, { ok: false, error: "key has expired" });
        }

        const wanted = String(body.scriptId || row.script_id || "");
        const script = data.scripts[wanted]
          || Object.values(data.scripts).find((s) => s.guild_id === row.guild_id)
          || null;
        if (!script) return send(res, 400, { ok: false, error: "no script registered for this key" });
        if (!isHttpUrl(script.script_url)) {
          return send(res, 409, { ok: false, error: "no payload url - rerun /setpanel" });
        }

        const lua = buildLoader({
          base: CONFIG.publicBase,
          scriptId: script.script_id,
          scriptUrl: script.script_url || "",
          key: row.key,
          body: script.loader || "",
        });
        return send(res, 200, {
          ok: true, scriptId: script.script_id,
          filename: `rip-${script.script_id}.lua`, lua,
        });
      }

      if (url.pathname === "/v1/web/resethwid" && req.method === "POST") {
        const row = getKey(key);
        if (!row) return send(res, 404, { ok: false, error: "key not found" });
        const discordId = String(body.discordId || "").replace(/\D/g, "");
        if (row.discord_id && discordId && row.discord_id !== discordId) {
          return send(res, 403, { ok: false, error: "that key belongs to another account" });
        }
        return send(res, 200, resetHwid(key, { force: false }));
      }

      return send(res, 404, { error: "unknown web route" });
    }

    if (url.pathname === "/v1/admin/create" && req.method === "POST") {
      if (!safeEqual(req.headers["x-admin-secret"] || "", CONFIG.adminSecret)) {
        return send(res, 403, { ok: false, error: "forbidden" });
      }
      const body = await readBody(req);
      const keys = createKeys({
        guildId: String(body.guildId || "cli"),
        scriptId: body.scriptId ? String(body.scriptId) : null,
        count: Number(body.count || 1),
        days: Number(body.days || 0),
        note: body.note ? String(body.note) : null,
      });
      return send(res, 200, { ok: true, keys });
    }

    send(res, 404, { error: "not found" });
  });

  server.on("error", (error) => {
    if (error.code === "EADDRINUSE") {
      console.error(`port ${CONFIG.port} is already in use. stop the other instance or set API_PORT.`);
      process.exit(1);
    }
    console.error("api server error", error);
    process.exit(1);
  });
  server.listen(CONFIG.port, () => console.log(`api on :${CONFIG.port}`));
  return server;
}

/* ------------------------------------------------------------- discord bot */

const reply = (payload) => ({ ...payload, flags: MessageFlags.Ephemeral });
const fmtExpiry = (row) => (row.expires_at > 0 ? `<t:${row.expires_at}:R>` : "lifetime");

function canManage(member, guild) {
  if (!member) return false;
  if (CONFIG.ownerIds.includes(member.id)) return true;
  if (member.permissions?.has(PermissionFlagsBits.Administrator)) return true;
  if (guild.manager_role && member.roles?.cache?.has(guild.manager_role)) return true;
  return false;
}

const keyEmbed = (row) =>
  new EmbedBuilder()
    .setTitle("Key status")
    .setColor(row.banned ? 0xed4245 : row.expires_at > 0 && row.expires_at <= now() ? 0xfaa61a : 0x57f287)
    .addFields(
      { name: "Key", value: `\`${row.key}\`` },
      { name: "Expires", value: fmtExpiry(row), inline: true },
      { name: "Executions", value: String(row.executions || 0), inline: true },
      { name: "Device", value: row.hwid ? "`bound`" : "`unbound`", inline: true },
      { name: "Last used", value: row.last_seen_at ? `<t:${row.last_seen_at}:R>` : "never", inline: true },
      { name: "Note", value: row.note || "-" },
    );

const panelEmbed = (guild) =>
  new EmbedBuilder()
    .setAuthor({ name: "Access" })
    .setTitle("Get your key working")
    .setColor(0x5865f2)
    .setDescription(
      guild.panel_text ||
      "Three steps. One key, one account, no sharing.",
    )
    .addFields(
      { name: "1. Activate", value: "Press **Activate Key** and paste the key you bought.", inline: false },
      { name: "2. Load", value: "Press **Get Script** and paste the code into your executor.", inline: false },
      { name: "3. Repeat", value: "Run the same code next time - no re-activation.", inline: false },
      { name: "Trouble?", value: "Use the menu below. Tickets for anything else.", inline: false },
    )
    .setFooter({ text: "Keys are single-use. Never share yours." })
    .setTimestamp();

const isHttpUrl = (value) => /^https?:\/\/[^\s"'<>]+$/i.test(String(value || ""));

// Emitted into every buyer's copy. The check runs first and the payload line is
// the only thing after it, so a buyer's copy cannot execute without a valid key.
function buildLoader({ base, scriptId, scriptUrl, key, body }) {
  const head = [
    "--[[ riP guard - nothing below the payload line runs without a valid key ]]",
    `local RIP_KEY = ${JSON.stringify(key)}`,
    `local RIP_SCRIPT = ${JSON.stringify(scriptId)}`,
    `local RIP_BASE = ${JSON.stringify(base)}`,
    `local RIP_URL = ${JSON.stringify(isHttpUrl(scriptUrl) ? scriptUrl : "")}`,
    "",
    "-- Executors disagree about where a machine id lives. Take the first that answers.",
    "local function ripDevice()",
    "    local ok, value = pcall(function() return gethwid() end)",
    "    if ok and type(value) == \"string\" and #value > 4 then return value end",
    "    ok, value = pcall(function() return syn.get_hwid() end)",
    "    if ok and type(value) == \"string\" and #value > 4 then return value end",
    "    ok, value = pcall(function() return game:GetService(\"RbxAnalyticsService\"):GetClientId() end)",
    "    if ok and type(value) == \"string\" and #value > 4 then return value end",
    "    ok, value = pcall(function() return tostring(game:GetService(\"Players\").LocalPlayer.UserId) end)",
    "    if ok and value and value ~= \"\" then return value end",
    "    return \"unknown-device\"",
    "end",
    "",
    "local http = game:GetService(\"HttpService\")",
    "local url = RIP_BASE .. \"/v1/check?key=\" .. http:UrlEncode(RIP_KEY)",
    "    .. \"&script_id=\" .. http:UrlEncode(RIP_SCRIPT)",
    "    .. \"&hwid=\" .. http:UrlEncode(ripDevice())",
    "",
    "-- Three tries: a dropped connection should not read as an invalid key.",
    "local decoded",
    "for attempt = 1, 3 do",
    "    local ok, res = pcall(game.HttpGet, game, url)",
    "    if ok and type(res) == \"string\" and #res > 0 then",
    "        local parsed, body = pcall(function() return http:JSONDecode(res) end)",
    "        if parsed and type(body) == \"table\" then decoded = body break end",
    "    end",
    "    if attempt < 3 then pcall(function() task.wait(0.5 * attempt) end) end",
    "end",
    "",
    "if not decoded then",
    "    return warn(\"riP: auth server unreachable - try again\")",
    "end",
    "if decoded.code ~= \"KEY_VALID\" then",
    "    return warn(\"riP: \" .. tostring(decoded.message or decoded.code))",
    "end",
    "",
    "if RIP_URL ~= \"\" then",
    "    local fetched, payload = pcall(game.HttpGet, game, RIP_URL)",
    "    if not fetched or type(payload) ~= \"string\" or #payload == 0 then",
    "        return warn(\"riP: payload download failed\")",
    "    end",
    "    local chunk, err = loadstring(payload)",
    "    if not chunk then",
    "        return warn(\"riP: payload did not compile - \" .. tostring(err))",
    "    end",
    "    return chunk()",
    "end",
  ].join("\n");
  return `${head}\n${body || ""}`;
}

const panelComponents = () => [
  new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("panel:redeem").setLabel("Activate Key").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("panel:script").setLabel("Get Script").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId("panel:status").setLabel("Check Access").setStyle(ButtonStyle.Secondary),
  ),
  new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId("panel:more")
      .setPlaceholder("More actions...")
      .addOptions(
        { label: "Copy my key", value: "copy", description: "Show the key again" },
        { label: "Switch device", value: "reset", description: "Move the key to a new PC" },
        { label: "Recent activity", value: "history", description: "Last checks on this key" },
        { label: "Claim buyer role", value: "role", description: "Take the role for active keys" },
        { label: "How this works", value: "help", description: "Steps, rules and where to get help" },
      ),
  ),
];

const staff = (builder) => builder.setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild);

const definitions = [
  new SlashCommandBuilder().setName("help").setDescription("How keys and the panel work"),
  new SlashCommandBuilder().setName("stats").setDescription("Live counters for this server"),

  staff(new SlashCommandBuilder().setName("announce").setDescription("Post an announcement"))
    .addChannelOption((o) => o.setName("channel").setDescription("Where").setRequired(true))
    .addStringOption((o) => o.setName("title").setDescription("Title").setRequired(true).setMaxLength(200))
    .addStringOption((o) => o.setName("body").setDescription("Message").setRequired(true).setMaxLength(3500))
    .addRoleOption((o) => o.setName("ping").setDescription("Role to ping")),

  staff(new SlashCommandBuilder().setName("giveaway").setDescription("Key giveaways"))
    .addSubcommand((s) => s.setName("start").setDescription("Open a giveaway")
      .addStringOption((o) => o.setName("prize").setDescription("What is being given away").setRequired(true))
      .addIntegerOption((o) => o.setName("winners").setDescription("How many winners").setMinValue(1).setMaxValue(50))
      .addIntegerOption((o) => o.setName("minutes").setDescription("Length in minutes").setMinValue(1).setMaxValue(10080))
      .addIntegerOption((o) => o.setName("days").setDescription("Key duration, blank = lifetime").setMinValue(1).setMaxValue(3650)))
    .addSubcommand((s) => s.setName("end").setDescription("Draw now in this channel"))
    .addSubcommand((s) => s.setName("reroll").setDescription("Redraw winners in this channel")),

  new SlashCommandBuilder().setName("ticket").setDescription("Support tickets")
    .addSubcommand((s) => s.setName("panel").setDescription("Post the ticket button in this channel")
      .addStringOption((o) => o.setName("text").setDescription("Message shown above the button")))
    .addSubcommand((s) => s.setName("close").setDescription("Close the ticket in this channel")
      .addStringOption((o) => o.setName("reason").setDescription("Reason")))
    .addSubcommand((s) => s.setName("add").setDescription("Add someone to this ticket")
      .addUserOption((o) => o.setName("user").setDescription("User").setRequired(true)))
    .addSubcommand((s) => s.setName("list").setDescription("Open tickets in this server")),

  staff(new SlashCommandBuilder().setName("config").setDescription("Server settings"))    .addSubcommand((s) => s.setName("show").setDescription("Current settings"))
    .addSubcommand((s) => s.setName("hwid-days").setDescription("HWID reset cooldown")
      .addIntegerOption((o) => o.setName("days").setDescription("0 disables the cooldown")
        .setRequired(true).setMinValue(0).setMaxValue(365)))
    .addSubcommand((s) => s.setName("manager-role").setDescription("Role allowed to run staff commands")
      .addRoleOption((o) => o.setName("role").setDescription("Role").setRequired(true)))
    .addSubcommand((s) => s.setName("buyer-role").setDescription("Role granted with an active key")
      .addRoleOption((o) => o.setName("role").setDescription("Role").setRequired(true)))
    .addSubcommand((s) => s.setName("panel-text").setDescription("Custom line at the top of the panel")
      .addStringOption((o) => o.setName("text").setDescription("Leave blank to reset").setMaxLength(600)))
    .addSubcommand((s) => s.setName("ticket-category").setDescription("Category new tickets are created in")
      .addChannelOption((o) => o.setName("category").setDescription("Category").setRequired(true)))
    .addSubcommand((s) => s.setName("auto-role").setDescription("Role given to every new member")
      .addRoleOption((o) => o.setName("role").setDescription("Role").setRequired(true))),

  staff(new SlashCommandBuilder().setName("setpanel").setDescription("Post the buyer panel"))
    .addChannelOption((o) => o.setName("channel").setDescription("Where to post").setRequired(true))
    .addStringOption((o) => o.setName("script_id").setDescription("Script ID").setRequired(true))
    .addStringOption((o) => o.setName("script_url").setDescription("Your hosted .lua payload URL").setRequired(true))
    .addStringOption((o) => o.setName("loader").setDescription("Extra Lua run after the guard"))
    .addRoleOption((o) => o.setName("manager_role").setDescription("Staff role"))
    .addRoleOption((o) => o.setName("buyer_role").setDescription("Buyer role")),

  staff(new SlashCommandBuilder().setName("setlogs").setDescription("Route logs to a webhook"))
    .addStringOption((o) => o.setName("webhook").setDescription("Discord webhook URL").setRequired(true)),

  staff(new SlashCommandBuilder().setName("whitelist").setDescription("Give one user a key"))
    .addUserOption((o) => o.setName("user").setDescription("Buyer").setRequired(true))
    .addIntegerOption((o) => o.setName("days").setDescription("Days (omit for lifetime)").setMinValue(1).setMaxValue(3650))
    .addStringOption((o) => o.setName("note").setDescription("Note")),

  staff(new SlashCommandBuilder().setName("unwhitelist").setDescription("Delete a user's key"))
    .addUserOption((o) => o.setName("user").setDescription("Buyer").setRequired(true)),

  staff(new SlashCommandBuilder().setName("blacklist").setDescription("Ban a user's key"))
    .addUserOption((o) => o.setName("user").setDescription("Buyer").setRequired(true))
    .addIntegerOption((o) => o.setName("days").setDescription("Ban length").setMinValue(1).setMaxValue(3650))
    .addStringOption((o) => o.setName("reason").setDescription("Reason shown to the buyer")),

  staff(new SlashCommandBuilder().setName("force-hwidreset").setDescription("Reset a device, ignoring cooldown"))
    .addUserOption((o) => o.setName("user").setDescription("Buyer").setRequired(true)),

  staff(new SlashCommandBuilder().setName("compensate").setDescription("Add days to every key"))
    .addIntegerOption((o) => o.setName("days").setDescription("Days to add").setRequired(true).setMinValue(1).setMaxValue(3650)),

  staff(new SlashCommandBuilder().setName("mod").setDescription("Moderation"))
    .addSubcommand((s) => s.setName("warn").setDescription("Warn a member")
      .addUserOption((o) => o.setName("user").setDescription("Member").setRequired(true))
      .addStringOption((o) => o.setName("reason").setDescription("Reason")))
    .addSubcommand((s) => s.setName("timeout").setDescription("Time a member out")
      .addUserOption((o) => o.setName("user").setDescription("Member").setRequired(true))
      .addIntegerOption((o) => o.setName("minutes").setDescription("Minutes").setRequired(true).setMinValue(1).setMaxValue(40320))
      .addStringOption((o) => o.setName("reason").setDescription("Reason")))
    .addSubcommand((s) => s.setName("kick").setDescription("Kick a member")
      .addUserOption((o) => o.setName("user").setDescription("Member").setRequired(true))
      .addStringOption((o) => o.setName("reason").setDescription("Reason")))
    .addSubcommand((s) => s.setName("ban").setDescription("Ban a member")
      .addUserOption((o) => o.setName("user").setDescription("Member").setRequired(true))
      .addIntegerOption((o) => o.setName("days").setDescription("Delete messages for N days").setMinValue(0).setMaxValue(7))
      .addStringOption((o) => o.setName("reason").setDescription("Reason")))
    .addSubcommand((s) => s.setName("purge").setDescription("Delete recent messages")
      .addIntegerOption((o) => o.setName("count").setDescription("1-100").setRequired(true).setMinValue(1).setMaxValue(100))),

  staff(new SlashCommandBuilder().setName("user").setDescription("Look up a user's key"))
    .addSubcommand((s) => s.setName("info").setDescription("Show key, device and status")
      .addUserOption((o) => o.setName("user").setDescription("Buyer").setRequired(true))),

  staff(new SlashCommandBuilder().setName("admin").setDescription("Staff key tools"))
    .addSubcommand((s) => s.setName("create-keys").setDescription("Create 1-500 keys")
      .addIntegerOption((o) => o.setName("count").setDescription("How many").setRequired(true).setMinValue(1).setMaxValue(500))
      .addIntegerOption((o) => o.setName("days").setDescription("Duration").setMinValue(1).setMaxValue(3650))
      .addStringOption((o) => o.setName("script_id").setDescription("Bind to a script"))
      .addStringOption((o) => o.setName("note").setDescription("Note")))
    .addSubcommand((s) => s.setName("revoke").setDescription("Delete a key")
      .addStringOption((o) => o.setName("key").setDescription("Key").setRequired(true)))
    .addSubcommand((s) => s.setName("key-days").setDescription("Add or set days on a key")
      .addStringOption((o) => o.setName("key").setDescription("Key").setRequired(true))
      .addIntegerOption((o) => o.setName("days").setDescription("Days").setRequired(true).setMinValue(1).setMaxValue(3650))
      .addStringOption((o) => o.setName("mode").setDescription("add or set")
        .addChoices({ name: "add", value: "add" }, { name: "set", value: "set" })))
    .addSubcommand((s) => s.setName("mass-whitelist").setDescription("Key everyone holding a role")
      .addRoleOption((o) => o.setName("role").setDescription("Role").setRequired(true))
      .addIntegerOption((o) => o.setName("days").setDescription("Duration").setMinValue(1).setMaxValue(3650)))
    .addSubcommand((s) => s.setName("unbind").setDescription("Release a key from its Discord account")
      .addStringOption((o) => o.setName("key").setDescription("Key").setRequired(true)))
    .addSubcommand((s) => s.setName("lookup").setDescription("Find a key by user or key")
      .addUserOption((o) => o.setName("user").setDescription("Discord user"))
      .addStringOption((o) => o.setName("key").setDescription("Key")))
    .addSubcommand((s) => s.setName("export").setDescription("Every key as JSON"))
    .addSubcommand((s) => s.setName("purge").setDescription("Delete expired and banned keys"))
    .addSubcommand((s) => s.setName("debug").setDescription("Health report for this server"))
    .addSubcommand((s) => s.setName("note").setDescription("Attach a note to a key")
      .addStringOption((o) => o.setName("key").setDescription("Key").setRequired(true))
      .addStringOption((o) => o.setName("text").setDescription("Note, blank clears it").setMaxLength(200)))
    .addSubcommand((s) => s.setName("audit").setDescription("Last 15 staff actions"))
    .addSubcommand((s) => s.setName("stats").setDescription("Project counters")),

  new SlashCommandBuilder().setName("key").setDescription("Buyer key commands")
    .addSubcommand((s) => s.setName("redeem").setDescription("Claim a key to your account"))
    .addSubcommand((s) => s.setName("status").setDescription("Your key status"))
    .addSubcommand((s) => s.setName("copy").setDescription("Show your key"))
    .addSubcommand((s) => s.setName("script").setDescription("Get your loader"))
    .addSubcommand((s) => s.setName("reset-hwid").setDescription("Move your key to a new device"))
    .addSubcommand((s) => s.setName("history").setDescription("Your last checks"))
    .addSubcommand((s) => s.setName("role").setDescription("Claim the buyer role")),
];

async function registerCommands() {
  const body = definitions.map((command) => command.toJSON());
  const rest = new REST({ version: "10" }).setToken(CONFIG.token);
  if (CONFIG.guildId) await rest.put(Routes.applicationGuildCommands(CONFIG.clientId, CONFIG.guildId), { body });
  else await rest.put(Routes.applicationCommands(CONFIG.clientId), { body });
  console.log(`registered ${body.length} commands`);
}

/* --------------------------------------------------------------- handlers */

// Both the buttons and the select menu land on the same handler; the menu sends
// the short value ("reset"), the button sends the full one.
const ACTION_SUB = {
  script: "script", role: "role", reset: "reset-hwid",
  status: "status", copy: "copy", history: "history",
};

async function handleKeyAction(interaction, guild, sub) {
  const row = keyForDiscord(interaction.user.id, guild.id);
  if (!row) return interaction.reply(reply({ content: "no key linked. use Activate Key on the panel." }));
  if (sub === "status") return interaction.reply(reply({ embeds: [keyEmbed(row)] }));
  if (sub === "copy") return interaction.reply(reply({ content: `\`${row.key}\`` }));

  if (sub === "script") {
    const script = data.scripts[row.script_id] || Object.values(data.scripts).find((s) => s.guild_id === guild.id);
    if (!script) return interaction.reply(reply({ content: "no loader configured yet - ask staff" }));
    if (!isHttpUrl(script.script_url)) {
      return interaction.reply(reply({ content: "that script has no payload url - rerun /setpanel" }));
    }
    const body = buildLoader({
      base: CONFIG.publicBase,
      scriptId: script.script_id,
      scriptUrl: script.script_url || "",
      key: row.key,
      body: script.loader || "",
    });
    // Discord caps message content at 2000 characters. A long loader used to be
    // sliced, handing the buyer a broken script; ship it as a file instead.
    if (body.length > 1800) {
      return interaction.reply(reply({
        content: "Your personal loader is attached. Paste it into your executor:",
        files: [{ attachment: Buffer.from(body, "utf8"), name: `rip-${script.script_id}.lua` }],
      }));
    }
    return interaction.reply(reply({
      content: `Your personal loader. Paste it into your executor:\n\`\`\`lua\n${body}\n\`\`\``,
    }));
  }

  if (sub === "history") {
    const entries = data.executions
      .filter((entry) => entry.key === row.key)
      .slice(-8)
      .reverse();
    if (!entries.length) return interaction.reply(reply({ content: "no checks recorded yet" }));
    return interaction.reply(reply({
      embeds: [new EmbedBuilder().setTitle("Recent checks").setColor(0x5865f2)
        .setDescription(entries.map((entry) =>
          `<t:${entry.at}:R> - ${entry.allowed ? "allowed" : `refused (${entry.reason})`} - \`${entry.scriptId || "any"}\``,
        ).join("\n"))],
    }));
  }

  if (sub === "reset-hwid") {
    const result = resetHwid(row.key, { guildId: guild.id });
    if (!result.ok) return interaction.reply(reply({ content: result.error }));
    return interaction.reply(reply({
      content: result.nextResetAt
        ? `device reset. run the script again to bind. next reset <t:${result.nextResetAt}:R>.`
        : "device reset. run the script again to bind.",
    }));
  }

  if (sub === "role") {
    if (!guild.buyer_role) return interaction.reply(reply({ content: "buyer role not configured" }));
    if (row.banned || (row.expires_at > 0 && row.expires_at <= now())) {
      return interaction.reply(reply({ content: "key is not active" }));
    }
    await interaction.member.roles.add(guild.buyer_role).catch(() => {});
    return interaction.reply(reply({ content: "role granted" }));
  }

  return interaction.reply(reply({ content: "unknown action - open a ticket if this keeps happening" }));
}

async function onTicketOpen(interaction, guild) {
  const existing = Object.values(data.tickets)
    .find((t) => t.open && t.user_id === interaction.user.id && t.guild_id === guild.id);
  if (existing) {
    return interaction.reply(reply({ content: `You already have a ticket open: <#${existing.channel_id}>` }));
  }

  const channel = await interaction.guild.channels.create({
    name: `ticket-${interaction.user.username}`.toLowerCase().slice(0, 90),
    type: ChannelType.GuildText,
    parent: guild.ticket_category || undefined,
    permissionOverwrites: [
      { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
      { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
      ...(guild.manager_role
        ? [{ id: guild.manager_role, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] }]
        : []),
    ],
  });

  openTicket(guild.id, channel.id, interaction.user.id);
  await channel.send(`<@${interaction.user.id}> - describe the issue and staff will reply. Close it with \`/ticket close\`.`)
    .catch(() => {});
  return interaction.reply(reply({ content: `Ticket opened: ${channel}` }));
}

async function onTicketCommand(interaction, guild, isStaff) {
  const sub = interaction.options.getSubcommand(true);

  if (sub === "panel") {
    if (!isStaff) return interaction.reply(reply({ content: "manager role required" }));
    const text = interaction.options.getString("text")
      || "Need help with a key? Open a ticket and staff will reply here.";
    await interaction.channel.send({
      embeds: [new EmbedBuilder().setTitle("Support").setColor(0x5865f2).setDescription(text)],
      components: [new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("ticket:open").setLabel("Open a ticket").setStyle(ButtonStyle.Primary),
      )],
    });
    return interaction.reply(reply({ content: "ticket panel posted" }));
  }

  const ticket = data.tickets[interaction.channelId];
  if (!ticket) return interaction.reply(reply({ content: "this is not a ticket channel" }));

  if (sub === "close") {
    if (!isStaff && ticket.user_id !== interaction.user.id) return interaction.reply(reply({ content: "not your ticket" }));
    const reason = interaction.options.getString("reason");
    closeTicket(interaction.channelId, interaction.user.id);
    await interaction.reply({ content: `Ticket closed${reason ? `: ${reason}` : ""}. Channel goes in 5s.` });
    setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
    return;
  }

  if (sub === "add") {
    const user = interaction.options.getUser("user", true);
    await interaction.channel.permissionOverwrites.edit(user.id, {
      ViewChannel: true, SendMessages: true, ReadMessageHistory: true,
    });
    return interaction.reply({ content: `${user} added to this ticket.` });
  }

  if (!isStaff) return interaction.reply(reply({ content: "manager role required" }));
  const open = Object.values(data.tickets).filter((t) => t.guild_id === guild.id && t.open);
  if (!open.length) return interaction.reply(reply({ content: "no open tickets" }));
  return interaction.reply(reply({
    content: open.map((t) => `<#${t.channel_id}> - <@${t.user_id}> - <t:${t.opened_at}:R>`).join("\n").slice(0, 1900),
  }));
}

async function onGiveawayCommand(interaction, guild, isStaff) {
  if (!isStaff) return interaction.reply(reply({ content: "manager role required" }));
  const sub = interaction.options.getSubcommand(true);

  if (sub === "start") {
    const prize = interaction.options.getString("prize", true);
    const winners = interaction.options.getInteger("winners") ?? 1;
    const minutes = interaction.options.getInteger("minutes") ?? 60;
    const days = interaction.options.getInteger("days") ?? 0;

    const id = `gw_${now()}_${Math.random().toString(36).slice(2, 8)}`;
    const giveaway = {
      id, guild_id: guild.id, channel_id: interaction.channelId, message_id: null,
      prize, winners, days, ended: false,
      ends_at: now() + minutes * 60, entries: [], winner_ids: [],
      host_id: interaction.user.id,
    };
    data.giveaways[id] = giveaway;
    save();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`giveaway:enter:${id}`).setLabel("Enter").setStyle(ButtonStyle.Primary),
    );
    const message = await interaction.channel.send({ embeds: [giveawayEmbed(giveaway)], components: [row] });
    giveaway.message_id = message.id;
    save();

    setTimeout(() => finishGiveaway(id), minutes * 60000).unref?.();
    return interaction.reply(reply({ content: `giveaway open for ${minutes} minutes` }));
  }

  const giveaway = Object.values(data.giveaways)
    .find((g) => g.channel_id === interaction.channelId && !g.ended);
  if (!giveaway) return interaction.reply(reply({ content: "no live giveaway in this channel" }));

  if (sub === "end") {
    await finishGiveaway(giveaway.id);
    return interaction.reply({ content: "drawn" });
  }

  giveaway.ended = false;
  delete giveaway.winner_ids;
  await finishGiveaway(giveaway.id);
  return interaction.reply({ content: "rerolled" });
}

async function onCommand(interaction) {
  const guild = getGuild(interaction.guildId);
  const isStaff = canManage(interaction.member, guild);

  switch (interaction.commandName) {
    case "help": {
      return interaction.reply(reply({
        embeds: [new EmbedBuilder().setTitle("How access works").setColor(0x5865f2)
          .setDescription([
            "**1 - Get a key** - from the shop, or from staff.",
            "**2 - Activate it** - `/key redeem`, or Activate Key.",
            "**3 - Load it** - Get Script, paste into your executor.",
            "**4 - Manage it** - Check Access, Switch Device, Claim Role.",
          ].join("\n"))
          .addFields({ name: "Rules", value: "One key, one account, one redemption. Device resets have a cooldown." })],
      }));
    }

    case "stats": {
      const counters = stats(interaction.guildId);
      return interaction.reply(reply({
        embeds: [new EmbedBuilder().setTitle("Live stats").setColor(0x5865f2).addFields(
          { name: "Keys", value: String(counters.total), inline: true },
          { name: "Active", value: String(counters.total - counters.expired - counters.banned), inline: true },
          { name: "Executions", value: String(counters.executions), inline: true },
        )],
      }));
    }

    case "ticket": {
      return onTicketCommand(interaction, guild, isStaff);
    }

    case "announce": {
      if (!isStaff) return interaction.reply(reply({ content: "manager role required" }));
      const channel = interaction.options.getChannel("channel", true);
      const title = interaction.options.getString("title", true);
      const body = interaction.options.getString("body", true);
      const ping = interaction.options.getRole("ping");

      await channel.send({
        content: ping ? `<@&${ping.id}>` : undefined,
        embeds: [new EmbedBuilder().setTitle(title).setColor(0x5865f2).setDescription(body).setTimestamp()],
      });
      return interaction.reply(reply({ content: `announcement posted in ${channel}` }));
    }

    case "giveaway": {
      return onGiveawayCommand(interaction, guild, isStaff);
    }

    case "config": {
      if (!isStaff) return interaction.reply(reply({ content: "manager role required" }));
      const sub = interaction.options.getSubcommand(true);

      if (sub === "hwid-days") {
        const days = interaction.options.getInteger("days", true);
        setGuild(guild.id, { hwid_reset_days: days });
        audit(guild, interaction.user, "config.hwid-days", `${days}d`);
        return interaction.reply(reply({ content: days === 0 ? "HWID resets are unlimited" : `HWID cooldown set to ${days}d` }));
      }

      if (sub === "manager-role") {
        const role = interaction.options.getRole("role", true);
        setGuild(guild.id, { manager_role: role.id });
        audit(guild, interaction.user, "config.manager-role", role.id);
        return interaction.reply(reply({ content: `staff role is now ${role}` }));
      }

      if (sub === "buyer-role") {
        const role = interaction.options.getRole("role", true);
        setGuild(guild.id, { buyer_role: role.id });
        audit(guild, interaction.user, "config.buyer-role", role.id);
        return interaction.reply(reply({ content: `buyer role is now ${role}` }));
      }

      if (sub === "panel-text") {
        const text = interaction.options.getString("text");
        setGuild(guild.id, { panel_text: text || null });
        audit(guild, interaction.user, "config.panel-text", text ? "updated" : "reset");
        return interaction.reply(reply({ content: text ? "panel text updated - repost with /setpanel" : "panel text reset" }));
      }

      if (sub === "ticket-category") {
        const category = interaction.options.getChannel("category", true);
        setGuild(guild.id, { ticket_category: category.id });
        audit(guild, interaction.user, "config.ticket-category", category.id);
        return interaction.reply(reply({ content: `tickets will open under **${category.name}**` }));
      }

      if (sub === "auto-role") {
        const role = interaction.options.getRole("role", true);
        setGuild(guild.id, { auto_role: role.id });
        audit(guild, interaction.user, "config.auto-role", role.id);
        return interaction.reply(reply({ content: `new members get ${role}` }));
      }

      const counters = stats(guild.id);
      return interaction.reply(reply({
        embeds: [new EmbedBuilder().setTitle("Settings").setColor(0x5865f2).addFields(
          { name: "Staff role", value: guild.manager_role ? `<@&${guild.manager_role}>` : "not set", inline: true },
          { name: "Buyer role", value: guild.buyer_role ? `<@&${guild.buyer_role}>` : "not set", inline: true },
          { name: "HWID cooldown", value: guild.hwid_reset_days === 0 ? "none" : `${guild.hwid_reset_days}d`, inline: true },
          { name: "Keys", value: String(counters.total), inline: true },
          { name: "Log webhook", value: guild.logs_webhook ? "set" : "not set", inline: true },
          { name: "Scripts", value: String(Object.values(data.scripts).filter((s) => s.guild_id === guild.id).length), inline: true },
        )],
      }));
    }

    case "setpanel": {
      if (!isStaff) return interaction.reply(reply({ content: "manager role required" }));
      const channel = interaction.options.getChannel("channel", true);
      const scriptId = interaction.options.getString("script_id", true);
      const loader = interaction.options.getString("loader") ?? "";
      const scriptUrl = interaction.options.getString("script_url", true);
      if (!isHttpUrl(scriptUrl)) {
        return interaction.reply(reply({ content: "script_url must be a full http(s) URL to your .lua payload" }));
      }
      const managerRole = interaction.options.getRole("manager_role");
      const buyerRole = interaction.options.getRole("buyer_role");

      data.scripts[scriptId] = { script_id: scriptId, guild_id: guild.id, loader, script_url: scriptUrl, created_at: now() };
      save();
      setGuild(guild.id, {
        ...(managerRole ? { manager_role: managerRole.id } : {}),
        ...(buyerRole ? { buyer_role: buyerRole.id } : {}),
      });

      const message = await channel.send({ embeds: [panelEmbed(guild)], components: panelComponents() });
      data.panels[guild.id] = { channel_id: channel.id, message_id: message.id, script_id: scriptId };
      save();
      audit(guild, interaction.user, "setpanel", `${scriptId} in ${channel.id}`);
      return interaction.reply(reply({ content: `panel posted in ${channel}` }));
    }

    case "setlogs": {
      if (!isStaff) return interaction.reply(reply({ content: "manager role required" }));
      const webhook = interaction.options.getString("webhook", true);
      if (!/^https:\/\/discord\.com\/api\/webhooks\/\d+\/[\w-]+$/.test(webhook)) {
        return interaction.reply(reply({ content: "not a Discord webhook URL" }));
      }
      setGuild(guild.id, { logs_webhook: webhook });
      audit(guild, interaction.user, "setlogs", "webhook updated");
      return interaction.reply(reply({ content: "log webhook stored" }));
    }

    case "whitelist": {
      if (!isStaff) return interaction.reply(reply({ content: "manager role required" }));
      const user = interaction.options.getUser("user", true);
      const days = interaction.options.getInteger("days") ?? 0;
      const note = interaction.options.getString("note");
      const [key] = createKeys({ guildId: guild.id, count: 1, days, note, discordId: user.id });
      if (guild.buyer_role) {
        const member = await interaction.guild.members.fetch(user.id).catch(() => null);
        await member?.roles.add(guild.buyer_role).catch(() => {});
      }
      audit(guild, interaction.user, "whitelist", `${key} -> ${user.id}${days ? ` ${days}d` : ""}`);
      return interaction.reply(reply({ content: `${user} whitelisted\n\`${key}\`` }));
    }

    case "unwhitelist": {
      if (!isStaff) return interaction.reply(reply({ content: "manager role required" }));
      const user = interaction.options.getUser("user", true);
      const row = keyForDiscord(user.id, guild.id);
      if (!row) return interaction.reply(reply({ content: "no key for that user" }));
      revoke(row.key);
      audit(guild, interaction.user, "unwhitelist", `${row.key} (${user.id})`);
      return interaction.reply(reply({ content: `removed \`${row.key}\`` }));
    }

    case "blacklist": {
      if (!isStaff) return interaction.reply(reply({ content: "manager role required" }));
      const user = interaction.options.getUser("user", true);
      const days = interaction.options.getInteger("days") ?? 0;
      const reason = interaction.options.getString("reason");
      const row = keyForDiscord(user.id, guild.id);
      if (!row) return interaction.reply(reply({ content: "no key for that user" }));
      ban(row.key, { reason, days });
      audit(guild, interaction.user, "blacklist", `${row.key} (${user.id})${days ? ` ${days}d` : ""}`);
      return interaction.reply(reply({ content: `banned \`${row.key}\`${days ? ` for ${days}d` : " indefinitely"}` }));
    }

    case "force-hwidreset": {
      if (!isStaff) return interaction.reply(reply({ content: "manager role required" }));
      const user = interaction.options.getUser("user", true);
      const row = keyForDiscord(user.id, guild.id);
      if (!row) return interaction.reply(reply({ content: "no key for that user" }));
      resetHwid(row.key, { force: true });
      audit(guild, interaction.user, "force-hwidreset", `${row.key} (${user.id})`);
      return interaction.reply(reply({ content: `device reset for ${user}` }));
    }

    case "compensate": {
      if (!isStaff) return interaction.reply(reply({ content: "manager role required" }));
      const days = interaction.options.getInteger("days", true);
      const rows = Object.values(data.keys).filter((k) => k.guild_id === guild.id);
      for (const row of rows) changeDays(row.key, days, "add");
      audit(guild, interaction.user, "compensate", `${days}d on ${rows.length} keys`);
      return interaction.reply(reply({ content: `added ${days}d to ${rows.length} keys` }));
    }

    case "user": {
      if (!isStaff) return interaction.reply(reply({ content: "manager role required" }));
      const user = interaction.options.getUser("user", true);
      const row = keyForDiscord(user.id, guild.id);
      if (!row) return interaction.reply(reply({ content: "no key for that user" }));
      return interaction.reply(reply({ embeds: [keyEmbed(row)] }));
    }

    case "admin": {
      if (!isStaff) return interaction.reply(reply({ content: "manager role required" }));
      const sub = interaction.options.getSubcommand(true);

      if (sub === "create-keys") {
        const days = interaction.options.getInteger("days") ?? 0;
        const keys = createKeys({
          guildId: guild.id,
          count: interaction.options.getInteger("count", true),
          days,
          scriptId: interaction.options.getString("script_id"),
          note: interaction.options.getString("note"),
        });
        audit(guild, interaction.user, "admin.create-keys", `${keys.length} keys${days ? ` ${days}d` : ""}`);
        return interaction.reply(reply({
          content: `created ${keys.length} keys`,
          files: [{ attachment: Buffer.from(keys.join("\n"), "utf8"), name: `keys-${now()}.txt` }],
        }));
      }

      if (sub === "revoke") {
        const key = interaction.options.getString("key", true);
        const removed = revoke(key);
        if (removed) audit(guild, interaction.user, "admin.revoke", key);
        return interaction.reply(reply({ content: removed ? `revoked \`${key}\`` : "key not found" }));
      }

      if (sub === "key-days") {
        const key = interaction.options.getString("key", true);
        const days = interaction.options.getInteger("days", true);
        const mode = interaction.options.getString("mode") ?? "add";
        const result = changeDays(key, days, mode);
        if (!result.ok) return interaction.reply(reply({ content: result.error }));
        audit(guild, interaction.user, "admin.key-days", `${key} ${mode} ${days}d`);
        return interaction.reply(reply({ content: `\`${key}\` expires <t:${result.expiresAt}:R>` }));
      }

      if (sub === "mass-whitelist") {
        const role = interaction.options.getRole("role", true);
        const days = interaction.options.getInteger("days") ?? 0;
        await interaction.deferReply(reply({}));
        const members = await interaction.guild.members.fetch();
        let created = 0;
        let skipped = 0;
        for (const member of members.values()) {
          if (member.user.bot || !member.roles.cache.has(role.id)) continue;
          if (keyForDiscord(member.id, guild.id)) { skipped += 1; continue; }
          createKeys({ guildId: guild.id, count: 1, days, discordId: member.id, note: role.name });
          created += 1;
        }
        audit(guild, interaction.user, "admin.mass-whitelist", `${created} issued, ${skipped} skipped`);
        return interaction.editReply({ content: `issued ${created}, skipped ${skipped} existing` });
      }

      if (sub === "note") {
        const key = interaction.options.getString("key", true);
        const row = getKey(key);
        if (!row) return interaction.reply(reply({ content: "key not found" }));
        row.note = interaction.options.getString("text") || null;
        save();
        audit(guild, interaction.user, "admin.note", key);
        return interaction.reply(reply({ content: row.note ? "note updated" : "note cleared" }));
      }

      if (sub === "debug") {
        const local = Object.values(data.scripts).filter((s) => s.guild_id === guild.id);
        const counters = stats(guild.id);
        const localhost = /127\.0\.0\.1|localhost/.test(CONFIG.publicBase);
        return interaction.reply(reply({
          embeds: [new EmbedBuilder().setTitle("Health report").setColor(localhost ? 0xed4245 : 0x57f287).addFields(
            { name: "API base", value: localhost ? `\`${CONFIG.publicBase}\` - not reachable from a client` : `\`${CONFIG.publicBase}\`` },
            { name: "Scripts", value: local.length ? local.map((s) => `\`${s.script_id}\``).join(", ") : "none registered" },
            { name: "Keys", value: `${counters.total} total - ${counters.expired} expired - ${counters.banned} banned` },
            { name: "Executions", value: String(counters.executions), inline: true },
            { name: "Checks served", value: String(metrics.checks), inline: true },
            { name: "Uptime", value: `${Math.floor((now() - metrics.started) / 60)}m`, inline: true },
          ).setTimestamp()],
        }));
      }

      if (sub === "unbind") {
        const key = interaction.options.getString("key", true);
        const row = getKey(key);
        if (!row) return interaction.reply(reply({ content: "key not found" }));
        const previous = row.discord_id;
        row.discord_id = null;
        row.redeemed_at = null;
        save();
        audit(guild, interaction.user, "admin.unbind", `${key} (was ${previous || "unclaimed"})`);
        return interaction.reply(reply({ content: `\`${key}\` can be redeemed again` }));
      }

      if (sub === "lookup") {
        const user = interaction.options.getUser("user");
        const keyArg = interaction.options.getString("key");
        const row = keyArg ? getKey(keyArg) : user ? keyForDiscord(user.id, guild.id) : null;
        if (!row) return interaction.reply(reply({ content: "nothing found" }));
        return interaction.reply(reply({ embeds: [keyEmbed(row)] }));
      }

      if (sub === "export") {
        const rows = Object.values(data.keys).filter((k) => k.guild_id === guild.id);
        return interaction.reply(reply({
          content: `${rows.length} keys`,
          files: [{ attachment: Buffer.from(JSON.stringify(rows, null, 2), "utf8"), name: `keys-${now()}.json` }],
        }));
      }

      if (sub === "purge") {
        const doomed = Object.values(data.keys).filter((k) =>
          k.guild_id === guild.id && (k.banned || (k.expires_at > 0 && k.expires_at <= now())));
        for (const row of doomed) delete data.keys[row.key];
        save();
        audit(guild, interaction.user, "admin.purge", `${doomed.length} keys`);
        return interaction.reply(reply({ content: `purged ${doomed.length} keys` }));
      }

      if (sub === "audit") {
        const entries = (data.audit || [])
          .filter((entry) => entry.guild_id === guild.id)
          .slice(-15)
          .reverse();
        if (!entries.length) return interaction.reply(reply({ content: "nothing staff-side has changed yet" }));
        return interaction.reply(reply({
          embeds: [new EmbedBuilder().setTitle("Staff audit").setColor(0x5865f2)
            .setDescription(entries.map((entry) =>
              `<t:${entry.at}:R> - <@${entry.actor_id}> - **${entry.action}** ${entry.detail}`.slice(0, 180),
            ).join("\n").slice(0, 4000))],
        }));
      }

      const counters = stats(guild.id);
      return interaction.reply(reply({
        embeds: [new EmbedBuilder().setTitle("Project stats").setColor(0x5865f2).addFields(
          { name: "Keys", value: String(counters.total), inline: true },
          { name: "Expired", value: String(counters.expired), inline: true },
          { name: "Banned", value: String(counters.banned), inline: true },
          { name: "Executions", value: String(counters.executions), inline: true },
        )],
      }));
    }

    case "key": {
      const sub = interaction.options.getSubcommand(true);
      if (sub === "redeem") {
        const modal = new ModalBuilder().setCustomId("redeem:submit").setTitle("Activate Key");
        modal.addComponents(new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId("key").setLabel("Your key").setStyle(TextInputStyle.Short)
            .setMinLength(4).setMaxLength(64).setRequired(true),
        ));
        return interaction.showModal(modal);
      }
      return handleKeyAction(interaction, guild, sub);
    }
  }
}

async function onButton(interaction) {
  const guild = getGuild(interaction.guildId);
  const [scope, action] = interaction.customId.split(":");

  if (scope === "ticket" && action === "open") return onTicketOpen(interaction, guild);

  if (scope === "giveaway" && action === "enter") {
    const [, , id] = interaction.customId.split(":");
    const giveaway = data.giveaways[id];
    if (!giveaway || giveaway.ended) {
      return interaction.reply(reply({ content: "this giveaway is closed" }));
    }
    const already = giveaway.entries.includes(interaction.user.id);
    giveaway.entries = already
      ? giveaway.entries.filter((u) => u !== interaction.user.id)
      : [...giveaway.entries, interaction.user.id];
    save();
    if (interaction.message?.editable) {
      await interaction.message.edit({ embeds: [giveawayEmbed(giveaway)] }).catch(() => {});
    }
    return interaction.reply(reply({
      content: already ? "entry withdrawn" : `entered - ${giveaway.entries.length} in the pot`,
    }));
  }

  if (scope !== "panel") return;

  if (action === "redeem") {
    const modal = new ModalBuilder().setCustomId("redeem:submit").setTitle("Activate Key");
    modal.addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId("key").setLabel("Your key").setStyle(TextInputStyle.Short)
        .setMinLength(4).setMaxLength(64).setRequired(true),
    ));
    return interaction.showModal(modal);
  }

  const sub = ACTION_SUB[action];
  if (!sub) return;
  return handleKeyAction(interaction, guild, sub);
}

async function onSelect(interaction) {
  const guild = getGuild(interaction.guildId);
  if (interaction.customId !== "panel:more") return;

  const value = interaction.values[0];
  if (value === "help") {
    return interaction.reply(reply({
      embeds: [new EmbedBuilder().setTitle("How access works").setColor(0x5865f2)
        .setDescription([
          "**1 - Activate Key** - paste the key you bought. One key, one account.",
          "**2 - Get Script** - copy the loader and run it in your executor.",
          "**3 - Check Access** - see time left and device state.",
          "",
          "**Switch device** when you change PC. Resets have a cooldown.",
          "**Lost your key or it is already claimed?** open a ticket.",
        ].join("\n"))],
    }));
  }

  return handleKeyAction(interaction, guild, ACTION_SUB[value] || value);
}

async function onModal(interaction) {
  const guild = getGuild(interaction.guildId);
  const [scope] = interaction.customId.split(":");

  if (scope === "redeem") {
    const key = interaction.fields.getTextInputValue("key").trim();
    const result = bindDiscord(key, interaction.user.id);
    if (!result.ok) return interaction.reply(reply({ content: result.error }));
    if (guild.buyer_role) await interaction.member.roles.add(guild.buyer_role).catch(() => {});
    return interaction.reply(reply({
      content: result.already
        ? "That key is already on your account."
        : "Key activated. Press **Get Script** to load it.",
      embeds: [keyEmbed(result.row)],
    }));
  }
}

/* ---------------------------------------------------------------- bootstrap */

export {
  CONFIG, data, flush, getGuild, setGuild, getKey, newKey, hwidHash, sign,
  safeEqual, createKeys, checkKey, signed, resetHwid, changeDays, revoke, ban,
  bindDiscord, keyForDiscord, stats, startApi, now, issueTicket, verifyTicket, metrics,
  drawGiveaway, openTicket, closeTicket, isTicketChannel, buildLoader, definitions,
  isKeyShape, normalizeKey, audit, maskId, publicRow, cooldownRemaining, hashIpAddress,
  keyVariants, maskKey, isHttpUrl, peekGuild,
};

async function main() {
  if (!CONFIG.token || !CONFIG.clientId) {
    console.error("DISCORD_TOKEN and DISCORD_CLIENT_ID are required");
    process.exit(1);
  }

  console.log(`riP | ${CONFIG.publicBase} | db ${CONFIG.dbPath}`);
  if (CONFIG.publicBase.includes("127.0.0.1") || CONFIG.publicBase.includes("localhost")) {
    console.warn("PUBLIC_BASE_URL is localhost - generated loaders only work on this machine");
  }
  if (!CONFIG.webSecret) {
    console.warn("WEB_SECRET is not set - web/server.mjs will receive 503 from /v1/web/*");
  }

  const api = startApi();
  const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers] });

  client.once("clientReady", () => console.log(`logged in as ${client.user.tag}`));
  client.on("guildMemberAdd", async (member) => {
    const guild = getGuild(member.guild.id);
    await raidShield(member, guild).catch(() => {});
    if (!member.guild.members.me?.permissions?.has(PermissionFlagsBits.ManageRoles)) return;
    // With a verification role configured, the auto role is granted after the
    // button, not before it — otherwise the gate is decorative.
    if (guild.auto_role && !guild.verify_role) await member.roles.add(guild.auto_role).catch(() => {});
    if (guild.welcome_channel) {
      const channel = member.guild.channels.cache.get(guild.welcome_channel);
      const text = (guild.welcome_text || "welcome {user} - read the rules, then pick up your key.")
        .replace(/\{user\}/g, `<@${member.id}>`)
        .replace(/\{server\}/g, member.guild.name);
      await channel?.send({ content: text.slice(0, 1900) }).catch(() => {});
    }
  });
  client.on("interactionCreate", async (interaction) => {
    try {
      if (interaction.isChatInputCommand()) await onCommand(interaction);
      else if (interaction.isButton()) await onButton(interaction);
      else if (interaction.isStringSelectMenu()) await onSelect(interaction);
      else if (interaction.isModalSubmit()) await onModal(interaction);
    } catch (error) {
      console.error("interaction failed", error);
      if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
        await interaction.reply(reply({ content: `error: ${error.message}` })).catch(() => {});
      }
    }
  });

  await registerCommands();
  await client.login(CONFIG.token);
  botClient = client;

  // resume giveaways that were open when the process restarted
  for (const giveaway of Object.values(data.giveaways)) {
    if (giveaway.ended) continue;
    const delay = Math.max(1000, giveaway.ends_at * 1000 - Date.now());
    setTimeout(() => finishGiveaway(giveaway.id), delay).unref?.();
  }

  for (const signal of ["SIGINT", "SIGTERM"]) {
    process.on(signal, () => {
      clearTimeout(saveTimer);
      try { flush(); } catch {}
      api.close();
      client.destroy();
      process.exit(0);
    });
  }
}

process.on("unhandledRejection", (error) => console.error("unhandled rejection", error));
process.on("uncaughtException", (error) => console.error("uncaught exception", error));

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  await main();
}
