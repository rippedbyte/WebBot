#!/usr/bin/env node
// Offline key management. Stop the bot first: it keeps the store in memory and
// will overwrite this file on its next save.
//
//   node tools/cli.mjs list [--guild ID]
//   node tools/cli.mjs create --count 10 --days 30 --note "beta" [--guild ID] [--script ID]
//   node tools/cli.mjs revoke --key KEY
//   node tools/cli.mjs ban --key KEY [--reason "text"] [--days 7]
//   node tools/cli.mjs unban --key KEY
//   node tools/cli.mjs reset --key KEY
//   node tools/cli.mjs stats [--guild ID]
//   node tools/cli.mjs export [--guild ID]

import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { randomBytes } from "node:crypto";

try { process.loadEnvFile?.(); } catch { /* no .env */ }

const DB_PATH = process.env.DB_PATH || "data/keygate.json";
const ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
const now = () => Math.floor(Date.now() / 1000);

const data = existsSync(DB_PATH)
  ? JSON.parse(readFileSync(DB_PATH, "utf8"))
  : { guilds: {}, scripts: {}, keys: {}, panels: {}, executions: [] };

const save = () => writeFileSync(DB_PATH, JSON.stringify(data));

function newKey(length = 32) {
  const out = [];
  while (out.length < length) {
    for (const byte of randomBytes(length)) {
      if (byte >= 208) continue;
      out.push(ALPHABET[byte % 52]);
      if (out.length === length) break;
    }
  }
  return out.join("");
}

const [command, ...rest] = process.argv.slice(2);
const flag = (name, fallback = null) => {
  const index = rest.indexOf(`--${name}`);
  return index === -1 ? fallback : rest[index + 1] ?? fallback;
};
const guild = flag("guild", "cli");

function create({ count = 1, days = 0, note = null, scriptId = null } = {}) {
  const total = Math.max(1, Math.min(500, Math.trunc(Number(count)) || 1));
  const expiresAt = days > 0 ? now() + Math.trunc(days) * 86400 : 0;
  const issued = [];
  for (let i = 0; i < total; i += 1) {
    let key;
    do { key = `RIP_${newKey(32)}`; } while (data.keys[key]);
    data.keys[key] = {
      key, guild_id: guild, script_id: scriptId, discord_id: null, note,
      created_at: now(), expires_at: expiresAt, hwid: null, hwid_reset_at: 0,
      banned: 0, ban_reason: null, executions: 0,
    };
    issued.push(key);
  }
  save();
  return issued;
}

switch (command) {
  case "create": {
    const keys = create({
      count: flag("count", 1),
      days: flag("days", 0),
      note: flag("note"),
      scriptId: flag("script"),
    });
    console.log(keys.join("\n"));
    console.error(`created ${keys.length} key(s) for guild ${guild}`);
    break;
  }

  case "list": {
    const rows = Object.values(data.keys).filter((k) => !flag("guild") || k.guild_id === guild);
    for (const row of rows) {
      const expiry = row.expires_at > 0 ? new Date(row.expires_at * 1000).toISOString().slice(0, 10) : "lifetime";
      const state = row.banned ? "BANNED" : row.expires_at > 0 && row.expires_at <= now() ? "EXPIRED" : "active";
      console.log([row.key, state, expiry, row.discord_id || "-", row.note || "-", `runs=${row.executions}`].join("\t"));
    }
    console.error(`${rows.length} key(s)`);
    break;
  }

  case "revoke": {
    const key = flag("key");
    if (!key || !data.keys[key]) { console.error("key not found"); process.exit(1); }
    delete data.keys[key];
    save();
    console.error(`revoked ${key}`);
    break;
  }

  case "ban":
  case "unban":
  case "reset": {
    const key = flag("key");
    const row = key ? data.keys[key] : null;
    if (!row) { console.error("key not found"); process.exit(1); }

    if (command === "ban") {
      row.banned = 1;
      row.ban_reason = flag("reason");
      const days = Number(flag("days", 0));
      if (days > 0) row.expires_at = now() + days * 86400;
    } else if (command === "unban") {
      row.banned = 0;
      row.ban_reason = null;
    } else {
      row.hwid = null;
      row.hwid_reset_at = now();
    }
    save();
    console.error(`${command} applied to ${key}`);
    break;
  }

  case "stats": {
    const rows = Object.values(data.keys).filter((k) => k.guild_id === guild);
    console.log(JSON.stringify({
      guild,
      total: rows.length,
      expired: rows.filter((k) => k.expires_at > 0 && k.expires_at <= now()).length,
      banned: rows.filter((k) => k.banned).length,
      executions: rows.reduce((sum, k) => sum + k.executions, 0),
    }, null, 2));
    break;
  }

  case "export": {
    const rows = Object.values(data.keys).filter((k) => k.guild_id === guild);
    console.log(JSON.stringify(rows, null, 2));
    break;
  }

  case "purge": {
    // Wipes everything a buyer touches; guild settings survive so roles and the
    // HWID cooldown do not have to be reconfigured. The old store is kept.
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    const backup = DB_PATH.replace(/\.json$/, `.backup-${stamp}.json`);
    writeFileSync(backup, JSON.stringify(data));
    const before = {
      scripts: Object.keys(data.scripts || {}).length,
      keys: Object.keys(data.keys || {}).length,
      panels: Object.keys(data.panels || {}).length,
    };
    data.scripts = {};
    data.keys = {};
    data.panels = {};
    data.tickets = {};
    data.giveaways = {};
    data.executions = [];
    data.audit = [];
    save();
    console.error(`purged ${before.scripts} scripts, ${before.keys} keys, ${before.panels} panels`);
    console.error(`backup: ${backup}`);
    break;
  }

  default:
    console.error("usage: node tools/cli.mjs <create|list|revoke|ban|unban|reset|stats|export|purge> [flags]");
    process.exit(1);
}
