// web/oauth.mjs — Discord OAuth2 + stateless signed sessions. No dependencies.
import { createHmac, timingSafeEqual, randomBytes } from "node:crypto";

const COOKIE = "kg_session";

export const oauthConfig = (env) => ({
  clientId: env.DISCORD_CLIENT_ID || "",
  clientSecret: env.DISCORD_CLIENT_SECRET || "",
  redirect: env.OAUTH_REDIRECT || "",
  guildId: env.DISCORD_GUILD_ID || "",
  verifyRole: env.VERIFY_ROLE_ID || "",
});

export const oauthReady = (cfg) => Boolean(cfg.clientId && cfg.clientSecret && cfg.redirect);

export function authUrl(cfg, state) {
  const params = new URLSearchParams({
    client_id: cfg.clientId,
    redirect_uri: cfg.redirect,
    response_type: "code",
    scope: "identify guilds",
    state,
    prompt: "consent",
  });
  return `https://discord.com/oauth2/authorize?${params}`;
}

export async function exchange(cfg, code) {
  const body = new URLSearchParams({
    client_id: cfg.clientId,
    client_secret: cfg.clientSecret,
    grant_type: "authorization_code",
    code,
    redirect_uri: cfg.redirect,
  });
  const res = await fetch("https://discord.com/api/oauth2/token", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body,
  });
  if (!res.ok) throw new Error(`token exchange failed (${res.status})`);
  return res.json();
}

export async function whoami(accessToken) {
  const res = await fetch("https://discord.com/api/users/@me", {
    headers: { authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) throw new Error("user fetch failed");
  const user = await res.json();
  return { id: user.id, username: user.username, globalName: user.global_name || null, avatar: user.avatar };
}

export async function inGuild(accessToken, guildId) {
  if (!guildId) return true;
  const res = await fetch("https://discord.com/api/users/@me/guilds", {
    headers: { authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) return false;
  const guilds = await res.json();
  return Array.isArray(guilds) && guilds.some((g) => g.id === guildId);
}

export const newState = () => randomBytes(16).toString("hex");

/* signed session cookie: userId.expiry.hmac */

export function issueSession(secret, userId, ttlSeconds = 86400) {
  const expires = Math.floor(Date.now() / 1000) + ttlSeconds;
  const mac = createHmac("sha256", secret).update(`${userId}.${expires}`).digest("base64url");
  return `${userId}.${expires}.${mac}`;
}

export function readSession(secret, cookieHeader) {
  const raw = /(?:^|;\s*)kg_session=([^;]+)/.exec(cookieHeader || "")?.[1];
  if (!raw) return null;
  const parts = raw.split(".");
  if (parts.length !== 3) return null;
  const [userId, expiry, mac] = parts;
  if (Number(expiry) < Math.floor(Date.now() / 1000)) return null;
  const expected = createHmac("sha256", secret).update(`${userId}.${expiry}`).digest("base64url");
  const a = Buffer.from(mac);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  return { userId };
}

export function sessionCookie(secret, userId, { secure = true } = {}) {
  const value = issueSession(secret, userId);
  return `kg_session=${value}; HttpOnly; SameSite=Lax; Path=/; Max-Age=86400${secure ? "; Secure" : ""}`;
}

export const clearCookie = () =>
  "kg_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0";

export const COOKIE_NAME = COOKIE;

