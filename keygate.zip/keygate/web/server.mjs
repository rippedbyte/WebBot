// web/server.mjs - static site + thin proxy to the bot. No dependencies.
// env: PORT (3000), BOT_URL (http://127.0.0.1:8080), WEB_SECRET, SESSION_SECRET,
//      TRUST_PROXY=1, COOKIE_INSECURE=1, RATE_LIMIT, CACHE_SECONDS.

import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { gzipSync } from "node:zlib";
import { extname, join, normalize, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import {
  authUrl, exchange, whoami, inGuild, newState, oauthConfig, oauthReady,
  readSession, sessionCookie, clearCookie,
} from "./oauth.mjs";

try { process.loadEnvFile?.(); } catch { /* no .env */ }

const HERE = fileURLToPath(new URL(".", import.meta.url));
const PUBLIC = resolve(HERE, "public");
const PORT = Number(process.env.PORT || 3000);
const BOT_URL = (process.env.BOT_URL || "http://127.0.0.1:8080").replace(/\/$/, "");
const WEB_SECRET = process.env.WEB_SECRET || "";
const SESSION_SECRET = process.env.SESSION_SECRET || process.env.WEB_SECRET || "dev-only-change-me";
const TRUST_PROXY = process.env.TRUST_PROXY === "1";
const COOKIE_INSECURE = process.env.COOKIE_INSECURE === "1";
const RATE_LIMIT = Math.max(10, Number(process.env.RATE_LIMIT || 60));
const CACHE_SECONDS = Math.max(0, Number(process.env.CACHE_SECONDS || 300));
const OAUTH = oauthConfig(process.env);

const TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".svg": "image/svg+xml",
  ".json": "application/json; charset=utf-8",
  ".txt": "text/plain; charset=utf-8",
  ".webmanifest": "application/manifest+json",
  ".png": "image/png",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".woff2": "font/woff2",
};

const COMPRESSIBLE = /^(text\/|application\/(json|manifest\+json)|image\/svg)/;
const SECURITY = {
  "x-content-type-options": "nosniff",
  "x-frame-options": "DENY",
  "referrer-policy": "no-referrer",
  "permissions-policy": "camera=(), microphone=(), geolocation=(), payment=()",
  "cross-origin-opener-policy": "same-origin",
  "content-security-policy": [
    "default-src 'self'",
    "img-src 'self' data:",
    "style-src 'self'",
    "script-src 'self'",
    "connect-src 'self'",
    "font-src 'self'",
    "base-uri 'none'",
    "form-action 'self'",
    "frame-ancestors 'none'",
  ].join("; "),
};

/* ------------------------------------------------------------------ limits */

const buckets = new Map();
let lastPrune = 0;

function allow(ip) {
  const stamp = Date.now();
  if (stamp - lastPrune > 120_000) {
    lastPrune = stamp;
    for (const [client, bucket] of buckets) {
      if (stamp - bucket.start > 120_000) buckets.delete(client);
    }
  }
  const bucket = buckets.get(ip);
  if (!bucket || stamp - bucket.start > 60_000) {
    buckets.set(ip, { start: stamp, count: 1 });
    return true;
  }
  bucket.count += 1;
  return bucket.count <= RATE_LIMIT;
}

function clientIp(req) {
  if (TRUST_PROXY) {
    const forwarded = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim();
    if (forwarded) return forwarded;
  }
  return req.socket?.remoteAddress || "0";
}

const secureRequest = (req) => !COOKIE_INSECURE
  && (req.headers["x-forwarded-proto"] === "https" || Boolean(req.socket?.encrypted));

/* ---------------------------------------------------------------- plumbing */

function baseHeaders(extra = {}) {
  return { ...SECURITY, ...extra };
}

function json(res, status, data, req) {
  const body = Buffer.from(JSON.stringify(data), "utf8");
  const headers = baseHeaders({
    "content-type": "application/json; charset=utf-8",
    "content-length": body.length,
    "cache-control": "no-store",
  });
  const compressed = maybeCompress(req, body, "application/json; charset=utf-8");
  if (compressed) {
    headers["content-encoding"] = "gzip";
    headers["vary"] = "accept-encoding";
    headers["content-length"] = compressed.length;
  }
  res.writeHead(status, headers);
  res.end(compressed || body);
}

function maybeCompress(req, body, type) {
  if (!COMPRESSIBLE.test(type || "")) return null;
  if (body.length < 1024) return null;
  if (!String(req.headers["accept-encoding"] || "").includes("gzip")) return null;
  return gzipSync(body);
}

async function readBody(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 8192) throw new Error("body too large");
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString("utf8")); } catch { return {}; }
}

async function bot(path, init = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const res = await fetch(`${BOT_URL}${path}`, {
      ...init,
      signal: controller.signal,
      headers: { "content-type": "application/json", "x-web-secret": WEB_SECRET, ...(init.headers || {}) },
    });
    const text = await res.text();
    let data;
    try { data = text ? JSON.parse(text) : {}; } catch { data = { error: "bad gateway response" }; }
    return { status: res.status, data };
  } catch {
    return { status: 502, data: { error: "bot unreachable" } };
  } finally {
    clearTimeout(timer);
  }
}

function sameOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  try {
    const host = req.headers["x-forwarded-host"] || req.headers.host;
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}

/* ------------------------------------------------------------------ routes */

const server = createServer(async (req, res) => {
  const url = new URL(req.url, "http://localhost");
  const ip = clientIp(req);

  if (url.pathname === "/auth/login") {
    if (!oauthReady(OAUTH)) return json(res, 503, { error: "discord login not configured" }, req);
    const state = newState();
    const secure = secureRequest(req);
    res.writeHead(302, baseHeaders({
      location: authUrl(OAUTH, state),
      "set-cookie": `kg_state=${state}; HttpOnly; SameSite=Lax; Path=/; Max-Age=600${secure ? "; Secure" : ""}`,
      "cache-control": "no-store",
    }));
    return res.end();
  }

  if (url.pathname === "/auth/callback") {
    const code = url.searchParams.get("code") || "";
    const state = url.searchParams.get("state") || "";
    const expected = /(?:^|;\s*)kg_state=([^;]+)/.exec(req.headers.cookie || "")?.[1];
    if (!code || !state || !expected || state !== expected) {
      res.writeHead(302, baseHeaders({ location: "/?error=state", "cache-control": "no-store" }));
      return res.end();
    }
    try {
      const token = await exchange(OAUTH, code);
      const user = await whoami(token.access_token);
      if (!(await inGuild(token.access_token, OAUTH.guildId))) {
        res.writeHead(302, baseHeaders({ location: "/?error=guild", "cache-control": "no-store" }));
        return res.end();
      }
      res.writeHead(302, baseHeaders({
        location: "/?welcome=1",
        "cache-control": "no-store",
        "set-cookie": [
          sessionCookie(SESSION_SECRET, user.id, { secure: secureRequest(req) }),
          "kg_state=; Path=/; Max-Age=0",
        ],
      }));
      return res.end();
    } catch {
      res.writeHead(302, baseHeaders({ location: "/?error=oauth", "cache-control": "no-store" }));
      return res.end();
    }
  }

  if (url.pathname === "/auth/logout") {
    res.writeHead(302, baseHeaders({ location: "/", "set-cookie": clearCookie(), "cache-control": "no-store" }));
    return res.end();
  }

  if (url.pathname.startsWith("/api/")) {
    if (!allow(ip)) return json(res, 429, { error: "slow down" }, req);
    if (req.method === "POST" && !sameOrigin(req)) return json(res, 403, { error: "cross-origin request" }, req);

    const session = readSession(SESSION_SECRET, req.headers.cookie);
    const signedIn = Boolean(session);

    if (url.pathname === "/api/me") {
      if (!signedIn) return json(res, 200, { signedIn: false, oauth: oauthReady(OAUTH) }, req);
      return json(res, 200, { signedIn: true, userId: session.userId, oauth: oauthReady(OAUTH) }, req);
    }

    if (url.pathname === "/api/health") {
      const { status } = await bot("/v1/health");
      return json(res, status === 200 ? 200 : 502, { ok: status === 200, bot: status === 200 ? "up" : "down" }, req);
    }

    if (url.pathname === "/api/stats") {
      const { status, data } = await bot("/v1/web/stats");
      return json(res, status, data, req);
    }

    if (url.pathname === "/api/key") {
      const key = String(url.searchParams.get("key") || "").trim();
      if (!key) return json(res, 400, { error: "key required" }, req);
      const { status, data } = await bot(`/v1/web/key?key=${encodeURIComponent(key)}`);
      return json(res, status, data, req);
    }

    if (url.pathname === "/api/history") {
      const key = String(url.searchParams.get("key") || "").trim();
      if (!key) return json(res, 400, { error: "key required" }, req);
      const { status, data } = await bot(`/v1/web/history?key=${encodeURIComponent(key)}`);
      return json(res, status, data, req);
    }

    if (url.pathname === "/api/mykey") {
      if (!signedIn) return json(res, 401, { error: "sign in with Discord first" }, req);
      const { status, data } = await bot(`/v1/web/mykey?discordId=${encodeURIComponent(session.userId)}`);
      return json(res, status, data, req);
    }

    if (url.pathname === "/api/scripts") {
      const { status, data } = await bot("/v1/web/scripts");
      return json(res, status, data, req);
    }

    if (req.method === "POST" && url.pathname === "/api/loader") {
      const body = await readBody(req);
      const key = String(body.key || "").trim();
      if (!key) return json(res, 400, { ok: false, error: "key required" }, req);
      const { status, data } = await bot("/v1/web/loader", {
        method: "POST",
        body: JSON.stringify({ key, scriptId: body.scriptId || undefined }),
      });
      return json(res, status, data, req);
    }

    if (req.method === "POST" && url.pathname === "/api/redeem") {
      // With OAuth configured the account id comes from the signed cookie only,
      // never from the request body.
      if (oauthReady(OAUTH) && !signedIn) {
        return json(res, 401, { ok: false, error: "sign in with Discord first" }, req);
      }
      const body = await readBody(req);
      const discordId = signedIn
        ? String(session.userId)
        : String(body.discordId || "").replace(/\D/g, "");
      if (!discordId) return json(res, 401, { ok: false, error: "sign in with Discord first" }, req);
      const { status, data } = await bot("/v1/web/redeem", {
        method: "POST",
        body: JSON.stringify({ ...body, discordId }),
      });
      return json(res, status, data, req);
    }

    if (req.method === "POST" && url.pathname === "/api/reset") {
      const body = await readBody(req);
      const payload = { key: body.key };
      if (signedIn) payload.discordId = String(session.userId);
      const { status, data } = await bot("/v1/web/resethwid", {
        method: "POST",
        body: JSON.stringify(payload),
      });
      return json(res, status, data, req);
    }

    return json(res, 404, { error: "unknown route" }, req);
  }

  return serveStatic(req, res, url.pathname);
});

/* ------------------------------------------------------------------- files */

const fileCache = new Map();

async function serveStatic(req, res, pathname) {
  if (req.method !== "GET" && req.method !== "HEAD") {
    return json(res, 405, { error: "method not allowed" }, req);
  }

  const requested = pathname === "/" ? "index.html" : decodeSafe(pathname);
  if (requested === null) return json(res, 400, { error: "bad path" }, req);

  // Extensionless routes: /dashboard -> dashboard.html, /docs -> docs.html.
  const clean = normalize(requested).replace(/^([/\\])+/, "");
  const asFile = join(PUBLIC, clean);
  const target = extname(clean) ? asFile : join(PUBLIC, `${clean}.html`);
  const file = resolve(target);
  if (file !== PUBLIC && !file.startsWith(PUBLIC + sep)) {
    return json(res, 403, { error: "forbidden" }, req);
  }
  if (/(^|[/\\])\./.test(file.slice(PUBLIC.length))) {
    return json(res, 404, { error: "not found" }, req);
  }

  const type = TYPES[extname(file).toLowerCase()] || "application/octet-stream";
  try {
    const info = await stat(file);
    if (!info.isFile()) throw new Error("not a file");

    const etag = `W/"${info.size.toString(16)}-${Math.floor(info.mtimeMs).toString(16)}"`;
    if (req.headers["if-none-match"] === etag) {
      res.writeHead(304, baseHeaders({ etag, "cache-control": cacheControl(file) }));
      return res.end();
    }

    const cacheKey = `${file}:${info.mtimeMs}:${req.headers["accept-encoding"] || ""}`;
    let entry = fileCache.get(cacheKey);
    if (!entry) {
      const raw = await readFile(file);
      const compressed = maybeCompress(req, raw, type);
      entry = { body: compressed || raw, encoding: compressed ? "gzip" : null };
      if (fileCache.size > 200) fileCache.clear();
      fileCache.set(cacheKey, entry);
    }

    const headers = baseHeaders({
      "content-type": type,
      "content-length": entry.body.length,
      "cache-control": cacheControl(file),
      etag,
      vary: "accept-encoding",
    });
    if (entry.encoding) headers["content-encoding"] = entry.encoding;

    res.writeHead(200, headers);
    if (req.method === "HEAD") return res.end();
    res.end(entry.body);
  } catch {
    return serve404(req, res);
  }
}

async function serve404(req, res) {
  try {
    const raw = await readFile(join(PUBLIC, "404.html"));
    res.writeHead(404, baseHeaders({
      "content-type": "text/html; charset=utf-8",
      "content-length": raw.length,
      "cache-control": "no-store",
    }));
    return res.end(req.method === "HEAD" ? undefined : raw);
  } catch {
    return json(res, 404, { error: "not found" }, req);
  }
}

async function serveIndex(req, res) {
  try {
    const raw = await readFile(join(PUBLIC, "index.html"));
    res.writeHead(200, baseHeaders({
      "content-type": "text/html; charset=utf-8",
      "content-length": raw.length,
      "cache-control": "no-cache",
    }));
    res.end(req.method === "HEAD" ? undefined : raw);
  } catch {
    json(res, 404, { error: "not found" }, req);
  }
}

function cacheControl(file) {
  const name = file.slice(PUBLIC.length);
  if (name === "index.html") return "no-cache";
  return `public, max-age=${CACHE_SECONDS}, must-revalidate`;
}

function decodeSafe(pathname) {
  try {
    const decoded = decodeURIComponent(pathname);
    if (decoded.includes("\0")) return null;
    return decoded;
  } catch {
    return null;
  }
}

server.on("error", (error) => {
  if (error.code === "EADDRINUSE") {
    console.error(`port ${PORT} is already in use. stop the other site process or set PORT.`);
    process.exit(1);
  }
  console.error("site error", error);
  process.exit(1);
});

server.listen(PORT, () => {
  console.log(`site on http://127.0.0.1:${PORT} -> bot ${BOT_URL}`);
  probeBot();
});

// A wrong or missing shared secret between the two processes is the single most
// common "the site is broken" cause: the bot answers 503/403 and every form
// quietly fails. Say it out loud at boot instead of leaving it to guesswork.
async function probeBot() {
  if (!WEB_SECRET) {
    console.warn("WEB_SECRET is not set - the bot will refuse /v1/web/* with 503");
    return;
  }
  const { status, data } = await bot("/v1/web/stats");
  if (status === 200) {
    console.log(`bridge ok - ${data.keys ?? 0} keys, ${data.scripts ?? 0} scripts`);
  } else if (status === 503) {
    console.warn("bot has no WEB_SECRET - set the same value in both .env files");
  } else if (status === 403) {
    console.warn("WEB_SECRET mismatch - the bot rejected the site's secret");
  } else {
    console.warn(`bridge probe failed (${status}) - is the bot running on ${BOT_URL}?`);
  }
}

for (const signal of ["SIGINT", "SIGTERM"]) {
  process.on(signal, () => {
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 2000).unref();
  });
}
