// riP portal — no dependencies.
// Talks only to /api/*, which proxies to the bot over a shared secret.

const $ = (id) => document.getElementById(id);
const KEY_RE = /^(?:RIP_)?[a-zA-Z]{32}$/;
const STORE = "keygate.key";
const THEME = "keygate-theme";
const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

const state = { key: "", row: null, session: null, busy: false, loader: null };

const EXECUTORS = [
  "Delta", "Vega X", "Codex", "SirHurt", "Solara", "Xeno", "Volt", "Potassium",
  "Wave", "Synapse Z", "Madium", "Cosmic", "Real", "Velocity", "MacSploit", "Swift",
];

/* ---------------------------------------------------------------- helpers */

async function api(path, init = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10_000);
  try {
    const res = await fetch(path, {
      ...init,
      signal: controller.signal,
      headers: { ...(init.body ? { "content-type": "application/json" } : {}), ...(init.headers || {}) },
    });
    let data = {};
    try { data = await res.json(); } catch { data = {}; }
    return { ok: res.ok, status: res.status, data };
  } catch (error) {
    return {
      ok: false, status: 0, data: {},
      error: error.name === "AbortError" ? "request timed out" : "network error",
    };
  } finally {
    clearTimeout(timer);
  }
}
function toast(text, kind = "") {
  const host = $("toasts");
  if (!host) return;
  const el = document.createElement("div");
  el.className = `toast ${kind}`.trim();
  el.textContent = text;
  host.append(el);
  setTimeout(() => {
    el.classList.add("out");
    setTimeout(() => el.remove(), 260);
  }, kind === "bad" ? 6500 : 4000);
}

function say(el, text, kind = "") {
  if (!el) return;
  el.textContent = text;
  el.className = `result ${kind}`.trim();
}

const compact = (value) => {
  const n = Number(value);
  if (!Number.isFinite(n)) return "0";
  return new Intl.NumberFormat(undefined, { notation: "compact", maximumFractionDigits: 1 }).format(n);
};

const fmtDate = (seconds) => (seconds
  ? new Date(seconds * 1000).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" })
  : "lifetime");

function rel(seconds) {
  const stamp = Number(seconds) || 0;
  if (!stamp) return "never";
  const delta = Math.floor(Date.now() / 1000) - stamp;
  if (delta < 0) {
    const ahead = -delta;
    if (ahead < 3600) return `in ${Math.ceil(ahead / 60)}m`;
    if (ahead < 86400) return `in ${Math.ceil(ahead / 3600)}h`;
    return `in ${Math.ceil(ahead / 86400)}d`;
  }
  if (delta < 60) return "just now";
  if (delta < 3600) return `${Math.floor(delta / 60)}m ago`;
  if (delta < 86400) return `${Math.floor(delta / 3600)}h ago`;
  if (delta < 2592000) return `${Math.floor(delta / 86400)}d ago`;
  return new Date(stamp * 1000).toLocaleDateString();
}

function duration(seconds) {
  const total = Math.max(0, Math.floor(Number(seconds) || 0));
  const days = Math.floor(total / 86400);
  const hours = Math.floor((total % 86400) / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  if (days) return `${days}d ${hours}h`;
  if (hours) return `${hours}h ${minutes}m`;
  return `${minutes}m`;
}

function animateCount(el, target) {
  if (!el) return;
  const end = Number(target) || 0;
  if (reduced) { el.textContent = compact(end); return; }
  const start = performance.now();
  const step = (now) => {
    const t = Math.min(1, (now - start) / 900);
    const eased = 1 - Math.pow(1 - t, 3);
    el.textContent = compact(Math.round(end * eased));
    if (t < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

function setBusy(button, busy, label) {
  if (!button) return;
  if (busy) {
    button.dataset.label = button.textContent;
    button.innerHTML = "";
    const spin = document.createElement("span");
    spin.className = "spinner";
    button.append(spin, document.createTextNode(label || "working"));
    button.disabled = true;
  } else {
    button.textContent = label || button.dataset.label || "done";
    button.disabled = false;
  }
}

async function copy(text, what = "Copied") {
  if (!text) return false;
  try {
    await navigator.clipboard.writeText(text);
    toast(`${what} to clipboard`, "ok");
    return true;
  } catch {
    const area = document.createElement("textarea");
    area.value = text;
    area.setAttribute("readonly", "");
    area.style.position = "fixed";
    area.style.opacity = "0";
    document.body.append(area);
    area.select();
    let done = false;
    try { done = document.execCommand("copy"); } catch { done = false; }
    area.remove();
    toast(done ? `${what} to clipboard` : "Clipboard blocked - select and copy", done ? "ok" : "bad");
    return done;
  }
}

async function pasteInto(input) {
  if (!input) return;
  try {
    const text = await navigator.clipboard.readText();
    if (!text) return toast("Clipboard is empty", "bad");
    input.value = text.trim();
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.focus();
  } catch {
    toast("Paste is blocked here - use ctrl+v", "bad");
    input.focus();
  }
}

const digits = (value) => String(value || "").replace(/\D/g, "");

/* ---------------------------------------------------------------- chrome */

function setupTheme() {
  const button = $("theme-toggle");
  const meta = $("meta-theme");
  const paint = (theme) => {
    document.documentElement.dataset.theme = theme;
    if (meta) meta.setAttribute("content", theme === "dark" ? "#0d0c12" : "#f7f7fb");
    if (button) {
      button.setAttribute("aria-pressed", String(theme === "dark"));
      button.setAttribute("aria-label", theme === "dark" ? "Switch to light mode" : "Switch to dark mode");
    }
  };
  paint(document.documentElement.dataset.theme === "dark" ? "dark" : "light");
  button?.addEventListener("click", () => {
    const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
    paint(next);
    try { localStorage.setItem(THEME, next); } catch { /* private mode */ }
  });
}

function setupScroll() {
  const nav = $("nav");
  const bar = $("scroll-progress");
  let ticking = false;
  const onScroll = () => {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(() => {
      const y = window.scrollY || 0;
      nav?.classList.toggle("scrolled", y > 12);
      if (bar) {
        const max = document.documentElement.scrollHeight - window.innerHeight;
        bar.style.width = `${max > 0 ? Math.min(100, (y / max) * 100) : 0}%`;
      }
      ticking = false;
    });
  };
  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });
  window.addEventListener("resize", onScroll, { passive: true });

  const burger = $("burger");
  const links = $("nav-links");
  if (burger && links) {
    const close = () => {
      links.classList.remove("open");
      burger.setAttribute("aria-expanded", "false");
    };
    burger.addEventListener("click", () => {
      const open = links.classList.toggle("open");
      burger.setAttribute("aria-expanded", String(open));
    });
    for (const link of links.querySelectorAll("a")) link.addEventListener("click", close);
    document.addEventListener("keydown", (event) => { if (event.key === "Escape") close(); });
  }
}

function setupReveal() {
  const items = document.querySelectorAll("[data-reveal]");
  if (!("IntersectionObserver" in window) || reduced) {
    for (const item of items) item.classList.add("is-visible");
    return;
  }
  const observer = new IntersectionObserver((entries) => {
    for (const entry of entries) {
      if (!entry.isIntersecting) continue;
      entry.target.classList.add("is-visible");
      observer.unobserve(entry.target);
    }
  }, { rootMargin: "0px 0px -8% 0px", threshold: 0.08 });
  for (const item of items) observer.observe(item);
}

function setupFeatureGlow() {
  for (const card of document.querySelectorAll(".feature")) {
    card.addEventListener("pointermove", (event) => {
      const box = card.getBoundingClientRect();
      card.style.setProperty("--mx", `${event.clientX - box.left}px`);
      card.style.setProperty("--my", `${event.clientY - box.top}px`);
    });
  }
}

function setupMarquee() {
  const tile = (name) => {
    const el = document.createElement("div");
    el.className = "exec-tile";
    const mono = document.createElement("span");
    mono.className = "mono";
    mono.textContent = name.split(" ").map((part) => part[0]).join("").slice(0, 2).toUpperCase();
    const label = document.createElement("small");
    label.textContent = name;
    el.append(mono, label);
    return el;
  };
  for (const id of ["exec-track", "exec-track-b"]) {
    const track = $(id);
    if (!track) continue;
    for (const name of EXECUTORS) track.append(tile(name));
  }
}

function renderFeed(entries) {
  const host = $("feed-rows");
  if (!host) return;
  host.textContent = "";
  if (!entries?.length) {
    const empty = document.createElement("div");
    empty.className = "feed-row";
    empty.textContent = "No checks recorded yet.";
    host.append(empty);
    return;
  }
  for (const entry of entries.slice(0, 4)) {
    const row = document.createElement("div");
    row.className = `feed-row${entry.allowed ? "" : " is-denied"}`;
    const key = document.createElement("span");
    key.className = "feed-key";
    key.textContent = entry.key || "....";
    const exec = document.createElement("span");
    exec.className = "feed-exec";
    exec.textContent = entry.allowed ? "allowed" : (entry.reason || "refused");
    const time = document.createElement("span");
    time.className = "feed-time";
    time.textContent = rel(entry.at);
    row.append(key, exec, time);
    host.append(row);
  }
}

async function loadStats() {
  const { ok, data } = await api("/api/stats");
  const chip = $("preview-chip");
  if (!ok) {
    if (chip) chip.textContent = "offline";
    const foot = $("preview-foot");
    if (foot) foot.textContent = "API unreachable - the bot may be down.";
    return;
  }
  if (chip) chip.textContent = "live";
  animateCount($("execution-count"), data.executions ?? data.served ?? 0);

  const delta = $("preview-delta");
  if (delta) {
    const valid = Number(data.valid) || 0;
    const denied = Number(data.denied) || 0;
    delta.textContent = `${compact(valid)} valid · ${compact(denied)} refused`;
    delta.className = "preview-delta";
  }

  const foot = $("preview-foot");
  if (foot) {
    const mins = Math.max(1, Math.round((Number(data.uptime) || 0) / 60));
    foot.textContent = `${data.keys ?? 0} keys · ${data.scripts ?? 0} scripts · up ${mins}m`;
  }

  renderFeed(data.recent);
  paintStatsValues(data);
  renderStatus(data);
  seen.stats = data;
  renderSetup();
}

function paintSession() {
  const box = $("auth");
  if (!box) return;
  box.textContent = "";
  const session = state.session || {};

  if (session.signedIn) {
    const badge = document.createElement("span");
    badge.className = "badge ok";
    badge.textContent = "verified";

    const who = document.createElement("span");
    who.className = "who";
    const avatar = document.createElement("span");
    avatar.className = "avatar";
    avatar.textContent = String(session.userId || "?").slice(-2);
    const id = document.createElement("span");
    id.textContent = `discord ...${String(session.userId || "").slice(-4)}`;
    who.append(avatar, id);

    const out = document.createElement("a");
    out.className = "link-btn";
    out.href = "/auth/logout";
    out.textContent = "sign out";

    box.append(badge, who, out);
    const field = $("discord-field");
    if (field) field.hidden = true;
    return;
  }

  if (session.oauth) {
    const link = document.createElement("a");
    link.className = "discord";
    link.href = "/auth/login";
    link.innerHTML = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M20.3 4.5A19 19 0 0 0 15.6 3l-.3.6a14 14 0 0 1 3.9 1.6 13 13 0 0 0-12.4 0A14 14 0 0 1 10.7 3.6L10.4 3A19 19 0 0 0 5.7 4.5C2.6 9.1 1.8 13.6 2.2 18a19 19 0 0 0 4.6 2.3l.9-1.5a12 12 0 0 1-1.9-.9l.5-.4a13.6 13.6 0 0 0 11.4 0l.5.4c-.6.4-1.2.7-1.9.9l.9 1.5A19 19 0 0 0 21.8 18c.5-5.1-.8-9.5-1.5-13.5zM8.7 15.4c-.9 0-1.6-.8-1.6-1.8s.7-1.8 1.6-1.8 1.6.8 1.6 1.8-.7 1.8-1.6 1.8zm6.6 0c-.9 0-1.6-.8-1.6-1.8s.7-1.8 1.6-1.8 1.6.8 1.6 1.8-.7 1.8-1.6 1.8z"/></svg>Sign in with Discord';
    box.append(link);
  } else {
    const badge = document.createElement("span");
    badge.className = "badge bad";
    badge.textContent = "discord login not configured";
    box.append(badge);
  }

  const label = $("discord-label");
  if (label) label.textContent = session.oauth ? "Discord user ID (manual)" : "Discord user ID";
  const field = $("discord-field");
  if (field) field.hidden = false;
}

// Keep the header honest about what the portal can actually do right now.
function paintNavAuth() {
  const link = document.querySelector(".link-quiet");
  if (!link) return;
  if (state.session?.signedIn) {
    link.href = "/auth/logout";
    link.textContent = "Sign out";
  } else if (state.session?.oauth) {
    link.href = "/auth/login";
    link.textContent = "Log in";
  } else {
    link.href = "#portal";
    link.textContent = "Portal";
  }
}

async function loadSession() {
  const { data } = await api("/api/me");
  state.session = data;
  paintSession();
  paintNavAuth();
  if (data?.signedIn) await adoptSessionKey();
}

// A signed-in buyer should never have to paste their own key: the bot already
// knows which key is bound to the account.
async function adoptSessionKey() {
  if (state.key) return;
  const { ok, data } = await api("/api/mykey");
  if (!ok || !Array.isArray(data.keys) || !data.keys.length) return;
  const row = data.keys[0];
  if (!row?.key) return;
  state.key = row.key;
  try { localStorage.setItem(STORE, row.key); } catch { /* private mode */ }
  const keyInput = $("key");
  const lookupInput = $("lookup");
  if (keyInput) keyInput.value = row.key;
  if (lookupInput) lookupInput.value = row.key;
  keyInputFeedback();
  paintDetails(row);
  paintActivity(row.key);
}

function keyState(row) {
  if (row.banned) return "banned";
  if (row.expiresAt && row.expiresAt * 1000 < Date.now()) return "expired";
  return "active";
}

function paintDetails(row) {
  const box = $("details");
  if (!box) return;
  state.row = row;
  box.hidden = false;
  const empty = $("lookup-empty");
  if (empty) empty.hidden = true;

  const kind = keyState(row);
  const pill = $("d-state");
  if (pill) {
    pill.className = `state ${kind}`;
    pill.textContent = kind;
  }
  if ($("d-exp")) $("d-exp").textContent = fmtDate(row.expiresAt);
  if ($("d-device")) $("d-device").textContent = row.bound ? "bound" : "not bound yet";
  if ($("d-runs")) $("d-runs").textContent = String(row.executions ?? 0);
  if ($("d-seen")) $("d-seen").textContent = row.lastSeenAt ? rel(row.lastSeenAt) : "never";

  const meter = $("meter");
  if (meter && row.expiresAt && row.createdAt && row.expiresAt > row.createdAt) {
    const total = row.expiresAt - row.createdAt;
    const left = Math.max(0, row.expiresAt - Math.floor(Date.now() / 1000));
    const pct = Math.round((left / total) * 100);
    meter.hidden = false;
    const fill = $("meter-fill");
    if (fill) {
      fill.style.width = `${pct}%`;
      fill.style.background = pct < 15 ? "var(--bad)" : "var(--ink-2)";
    }
    if ($("meter-label")) $("meter-label").textContent = left > 0 ? `${duration(left)} left` : "expired";
  } else if (meter) {
    meter.hidden = true;
  }

  const meta = $("d-meta");
  if (meta) {
    meta.textContent = "";
    const chips = [];
    if (row.scriptId) chips.push(`script: ${row.scriptId}`);
    if (row.note) chips.push(`note: ${row.note}`);
    if (row.discordId) chips.push(`owner: ${row.discordId}`);
    if (row.banReason) chips.push(`reason: ${row.banReason}`);
    for (const text of chips) {
      const chip = document.createElement("span");
      chip.className = "chip";
      chip.textContent = text;
      meta.append(chip);
    }
  }

  const reset = $("reset");
  if (reset) {
    if (kind === "banned") {
      reset.hidden = true;
    } else {
      reset.hidden = false;
      if ((row.cooldownSeconds || 0) > 0) {
        reset.disabled = true;
        reset.textContent = `switch device in ${duration(row.cooldownSeconds)}`;
      } else {
        reset.disabled = !row.bound;
        reset.textContent = row.bound ? "Switch device" : "Device not bound yet";
      }
    }
  }
}

async function paintActivity(key) {
  const box = $("activity");
  const list = $("activity-list");
  if (!box || !list) return;
  const { ok, data } = await api(`/api/history?key=${encodeURIComponent(key)}`);
  list.textContent = "";
  if (!ok || !data.executions?.length) { box.hidden = true; return; }

  for (const entry of data.executions.slice(0, 6)) {
    const li = document.createElement("li");
    if (!entry.allowed) li.className = "denied";
    const time = document.createElement("time");
    time.textContent = rel(entry.at);
    const text = document.createElement("span");
    const label = document.createElement("b");
    label.textContent = entry.allowed ? "allowed" : `refused - ${entry.reason || "unknown"}`;
    text.append(label, document.createTextNode(entry.scriptId ? ` - ${entry.scriptId}` : ""));
    li.append(time, text);
    list.append(li);
  }
  box.hidden = false;
}

async function lookup(raw, { quiet = false } = {}) {
  const key = String(raw || "").trim();
  const result = $("lookup-result");
  if (!KEY_RE.test(key)) return say(result, "Keys are 32 letters, with or without the RIP_ prefix.", "bad");

  const { ok, status, data } = await api(`/api/key?key=${encodeURIComponent(key)}`);
  if (!ok) {
    const details = $("details");
    if (details) details.hidden = true;
    const empty = $("lookup-empty");
    if (empty) empty.hidden = false;
    return say(result, data.error || (status === 404 ? "No key with that value." : "Lookup failed."), "bad");
  }

  state.key = key;
  try { localStorage.setItem(STORE, key); } catch { /* private mode */ }
  if ($("lookup")) $("lookup").value = key;
  paintDetails(data);
  paintActivity(key);
  if (!quiet) say(result, "Loaded.", "ok");
}

async function activate(event) {
  event.preventDefault();
  const result = $("activate-result");
  const key = String($("key")?.value || "").trim();
  if (!KEY_RE.test(key)) return say(result, "Keys are 32 letters, with or without the RIP_ prefix.", "bad");

  const discordId = state.session?.signedIn
    ? String(state.session.userId)
    : digits($("discord")?.value);
  if (!state.session?.signedIn && discordId.length < 15) {
    return say(result, "That Discord ID looks too short.", "bad");
  }

  const button = $("activate");
  if (state.busy) return;
  state.busy = true;
  setBusy(button, true, "activating");

  const { ok, data } = await api("/api/redeem", {
    method: "POST",
    body: JSON.stringify({ key, discordId }),
  });

  state.busy = false;
  setBusy(button, false, "Activate key");

  if (!ok) {
    const message = data.error || "Could not activate that key.";
    say(result, message, "bad");
    toast(message, "bad");
    return;
  }

  state.key = key;
  try { localStorage.setItem(STORE, key); } catch { /* private mode */ }
  if ($("lookup")) $("lookup").value = key;
  say(result, data.already ? "Already active on this account." : "Activated.", "ok");
  toast(data.already ? "Key already on your account" : "Key activated", "ok");
  await lookup(key, { quiet: true });
}

async function resetDevice() {
  if (!state.key) return;
  const result = $("lookup-result");
  const button = $("reset");
  setBusy(button, true, "resetting");

  const body = { key: state.key };
  if (state.session?.signedIn) body.discordId = String(state.session.userId);

  const { ok, data } = await api("/api/reset", { method: "POST", body: JSON.stringify(body) });
  setBusy(button, false, "Switch device");

  if (!ok || data.ok === false) {
    const message = data.error || "Reset failed.";
    say(result, message, "bad");
    toast(message, "bad");
    return;
  }
  say(result, "Device cleared. Run the loader again to bind the new machine.", "ok");
  toast("Device reset", "ok");
  await lookup(state.key, { quiet: true });
}

async function buildLoader() {
  const result = $("loader-result");
  const key = state.key || String($("lookup")?.value || $("key")?.value || "").trim();
  if (!key) return say(result, "Load a key first - activate or look one up above.", "bad");

  const button = $("get-loader");
  setBusy(button, true, "building");
  const { ok, data } = await api("/api/loader", {
    method: "POST",
    body: JSON.stringify({ key }),
  });
  setBusy(button, false, "Build loader");

  if (!ok) {
    say(result, data.error || "Could not build the loader.", "bad");
    return;
  }

  state.loader = data;
  const box = $("loader-out");
  const code = $("loader-code");
  if (code) code.textContent = data.lua;
  if (box) box.hidden = false;
  if ($("copy-loader")) $("copy-loader").hidden = false;
  if ($("download-loader")) $("download-loader").hidden = false;
  say(result, `Built for ${data.scriptId}. Paste it into your executor.`, "ok");
}

function downloadLoader() {
  if (!state.loader?.lua) return;
  const blob = new Blob([state.loader.lua], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = state.loader.filename || "rip.lua";
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

function keyInputFeedback() {
  const input = $("key");
  const hint = $("key-hint");
  if (!input || !hint) return;
  const value = input.value.trim();
  if (!value) {
    delete input.dataset.valid;
    hint.textContent = "32 letters, optional RIP_ prefix.";
    return;
  }
  const valid = KEY_RE.test(value);
  input.dataset.valid = String(valid);
  hint.textContent = valid ? "Looks right." : "That is not the right length or characters yet.";
}

function setupForms() {
  $("key")?.addEventListener("input", keyInputFeedback);
  $("activate-form")?.addEventListener("submit", activate);
  $("lookup-form")?.addEventListener("submit", (event) => {
    event.preventDefault();
    lookup($("lookup")?.value.trim() || $("key")?.value.trim());
  });
  $("reset")?.addEventListener("click", resetDevice);
  $("get-loader")?.addEventListener("click", buildLoader);
  $("download-loader")?.addEventListener("click", downloadLoader);
  $("copy-loader")?.addEventListener("click", () => {
    if (state.loader?.lua) copy(state.loader.lua, "Loader copied");
  });
  $("paste-key")?.addEventListener("click", () => pasteInto($("key")));
  $("paste-id")?.addEventListener("click", () => pasteInto($("discord")));
  $("copy-key")?.addEventListener("click", () => {
    if (state.key) copy(state.key, "Key copied");
  });

  document.addEventListener("keydown", (event) => {
    if (event.key !== "/" || event.metaKey || event.ctrlKey) return;
    const tag = document.activeElement?.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA") return;
    event.preventDefault();
    $("key")?.focus();
  });
}

const DEMO_REPLIES = {
  activate: "Paste the key from your order. One key, one account, one redemption.",
  script: "-- riP guard\nlocal RIP_KEY = \"RIP_******************************\"\n-- checks /v1/check, then loads your payload",
  role: "Buyer role granted. Run `/key status` any time you need the expiry.",
  hwid: "Device cleared. Run the loader again on the new machine to bind it.",
  check: "Active · lifetime · 412 runs · bound to this device",
};

function setupDemo() {
  const reply = $("demo-reply");
  const body = $("demo-reply-body");
  const actions = $("demo-actions");
  if (!reply || !body || !actions) return;

  actions.addEventListener("click", (event) => {
    const button = event.target.closest("[data-panel]");
    if (!button) return;
    const name = button.dataset.panel;
    const text = DEMO_REPLIES[name] || "Nothing to show.";
    body.textContent = "";
    if (name === "script") {
      const pre = document.createElement("pre");
      pre.textContent = text;
      body.append(pre);
    } else {
      body.textContent = text;
    }
    reply.hidden = false;
    for (const other of actions.querySelectorAll("[data-panel]")) {
      other.classList.toggle("is-active", other === button);
    }
  });
}

function readQuery() {
  const params = new URLSearchParams(window.location.search);
  const error = params.get("error");
  const messages = {
    state: "Login expired before it finished. Try again.",
    guild: "That account is not in the server. Join first, then sign in.",
    oauth: "Discord did not complete the login.",
  };
  if (error) toast(messages[error] || "Login failed.", "bad");
  if (params.get("welcome")) toast("Signed in with Discord", "ok");
  if (error || params.get("welcome")) {
    window.history.replaceState({}, "", window.location.pathname + window.location.hash);
  }
}

/* -------------------------------------------------------------------- boot */

setupTheme();
setupScroll();
setupReveal();
setupFeatureGlow();
setupMarquee();
setupDemo();
setupForms();
readQuery();

if ($("year")) $("year").textContent = String(new Date().getFullYear());

const stored = (() => {
  try { return localStorage.getItem(STORE) || ""; } catch { return ""; }
})();
if (stored) {
  if ($("key")) $("key").value = stored;
  if ($("lookup")) $("lookup").value = stored;
  keyInputFeedback();
  lookup(stored, { quiet: true });
}

loadStats();
loadScripts();
loadSession();

document.addEventListener("visibilitychange", () => {
  if (document.hidden) return;
  loadStats();
  if (state.key) lookup(state.key, { quiet: true });
});
setInterval(() => { if (!document.hidden) loadStats(); }, 90_000);

function paintStatsValues(data) {
  for (const el of document.querySelectorAll("[data-stat]")) {
    const key = el.dataset.stat;
    if (key in data) el.textContent = compact(data[key] ?? 0);
  }
}

function renderStatus(data) {
  const body = $("status-feed");
  if (body) {
    body.textContent = "";
    const rows = data.recent || [];
    if (!rows.length) {
      const tr = document.createElement("tr");
      const td = document.createElement("td");
      td.colSpan = 4;
      td.className = "muted";
      td.textContent = "No checks recorded yet.";
      tr.append(td);
      body.append(tr);
    }
    for (const entry of rows) {
      const tr = document.createElement("tr");
      const when = document.createElement("td");
      when.textContent = rel(entry.at);
      const key = document.createElement("td");
      key.className = "feed-key";
      key.textContent = entry.key || "....";
      const script = document.createElement("td");
      script.textContent = entry.scriptId || "any";
      const res = document.createElement("td");
      res.className = entry.allowed ? "ok" : "bad";
      res.textContent = entry.allowed ? "allowed" : (entry.reason || "refused");
      tr.append(when, key, script, res);
      body.append(tr);
    }
  }
  const health = $("health");
  if (health) health.textContent = "all systems normal";
  const foot = $("status-foot");
  if (foot) foot.textContent = `uptime ${duration(data.uptime)} · ${data.keysActive ?? 0} active keys · ${data.scripts ?? 0} scripts`;
}

async function loadScripts() {
  const body = $("scripts-body");
  if (!body) return;
  const { ok, data } = await api("/api/scripts");
  seen.scripts = ok ? (data.scripts || []) : [];
  renderSetup();
  body.textContent = "";
  if (!ok || !data.scripts?.length) {    const tr = document.createElement("tr");
    const td = document.createElement("td");
    td.colSpan = 3;
    td.className = "muted";
    td.textContent = "No scripts registered yet.";
    tr.append(td);
    body.append(tr);
    return;
  }
  for (const script of data.scripts) {
    const tr = document.createElement("tr");
    const id = document.createElement("td");
    id.innerHTML = "";
    const code = document.createElement("code");
    code.textContent = script.id || "-";
    id.append(code);
    const guild = document.createElement("td");
    guild.textContent = script.guildId || "-";
    const url = document.createElement("td");
    url.textContent = script.hasUrl ? "set" : "missing";
    tr.append(id, guild, url);
    body.append(tr);
  }
}

const seen = { stats: null, scripts: null };

function renderSetup() {
  const card = $("setup-card");
  const list = $("setup-list");
  if (!card || !list || !seen.stats) return;
  const items = [];
  if (!seen.scripts?.length) items.push("Register a script: /setpanel channel:#access script_id:hub script_url:https://your.cdn/payload.lua");
  else if (!seen.scripts.some((s) => s.hasUrl)) items.push("That script has no payload url - rerun /setpanel with a full https:// url.");
  if (!seen.stats.keys) items.push("Create keys: /admin create-keys count:25 (returns a .txt file)");
  if (!items.length) { card.hidden = true; return; }
  card.hidden = false;
  list.textContent = "";
  for (const text of items) {
    const li = document.createElement("li");
    li.textContent = text;
    list.append(li);
  }
}

window.__keygateReady = true;

