/* Shared chrome for inner pages. The landing page inlines its own header so the
   first paint never waits on a script. */
(function () {
  var page = document.body.dataset.page || "";
  var links = [
    ["/#features", "Features"], ["/#panel", "Panel"], ["/#pipeline", "Delivery"],
    ["/pricing", "Pricing"], ["/docs", "Docs"], ["/status", "Status"],
    ["/changelog", "Changelog"], ["/dashboard", "Dashboard"],
  ];
  var nav = links.map(function (p) {
    var on = page && p[0].indexOf("/" + page) === 0 ? ' class="is-current"' : "";
    return '<a href="' + p[0] + '"' + on + ">" + p[1] + "</a>";
  }).join("");

  var mark = '<img src="/assets/mark.svg" alt="" width="24" height="24" />';
  var moon = '<svg class="i-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5Z"/></svg>';
  var sun = '<svg class="i-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>';

  var head = document.getElementById("site-header");
  if (head) {
    head.innerHTML =
      '<header class="nav" id="nav"><div class="nav-inner"><div class="nav-left">' +
      '<a class="brand" href="/" aria-label="riP home">' + mark + "<span>riP</span></a>" +
      '<nav class="nav-links" id="nav-links" aria-label="Primary">' + nav + "</nav></div>" +
      '<div class="nav-actions"><a class="nav-invite" href="/docs">Docs</a>' +
      '<button class="theme-toggle" id="theme-toggle" type="button" aria-label="Switch theme" aria-pressed="false">' +
      moon + sun + "</button>" +
      '<a class="link-quiet" href="/dashboard">Log in</a>' +
      '<a class="btn btn-primary" href="/dashboard">Dashboard</a>' +
      '<button class="burger" id="burger" aria-expanded="false" aria-controls="nav-links" aria-label="Menu"><span></span><span></span></button>' +
      "</div></div></header>";
  }
  var foot = document.getElementById("site-footer");
  if (foot) {
    foot.innerHTML =
      '<footer class="footer"><div class="footer-inner">' +
      '<div class="footer-left">' + mark + "<span>riP</span></div>" +
      '<div class="footer-links"><a href="/#features">Features</a><a href="/#panel">Panel</a>' +
      '<a href="/pricing">Pricing</a><a href="/docs">Docs</a><a href="/status">Status</a>' +
      '<a href="/dashboard">Dashboard</a></div>' +
      '<span class="footer-year">© <span id="year">2026</span> riP</span>' +
      "</div></footer>";
  }

  var script = document.createElement("script");
  script.src = "/palette.js";
  document.body.appendChild(script);
})();
