/* Command palette: Cmd/Ctrl+K anywhere. No deps. */
(function () {
  var items = [
    ["Dashboard", "/dashboard"], ["Docs", "/docs"], ["Status", "/status"],
    ["Pricing", "/pricing"], ["Changelog", "/changelog"],
    ["Features", "/#features"], ["Panel", "/#panel"], ["FAQ", "/#faq"],
  ];
  var overlay = document.createElement("div");
  overlay.className = "palette";
  overlay.hidden = true;
  overlay.innerHTML =
    '<div class="palette-panel" role="dialog" aria-modal="true" aria-label="Command palette">' +
    '<input class="palette-input" placeholder="Jump to..." aria-label="Search" />' +
    '<ul class="palette-list"></ul>' +
    '<p class="palette-foot">up/down move - enter opens - esc closes</p></div>';
  var input = overlay.querySelector(".palette-input");
  var list = overlay.querySelector(".palette-list");
  var filtered = items.slice();
  var cursor = 0;

  function paint() {
    list.innerHTML = "";
    filtered.forEach(function (pair, i) {
      var li = document.createElement("li");
      li.className = i === cursor ? "is-active" : "";
      li.innerHTML = "<span>" + pair[0] + "</span><code>" + pair[1] + "</code>";
      li.addEventListener("click", function () { go(pair[1]); });
      list.appendChild(li);
    });
    if (!filtered.length) list.innerHTML = '<li class="is-empty">nothing matches</li>';
  }

  function go(href) {
    overlay.hidden = true;
    window.location.href = href;
  }

  function open() {
    overlay.hidden = false;
    document.body.classList.add("palette-open");
    input.value = "";
    filtered = items.slice();
    cursor = 0;
    paint();
    input.focus();
  }

  function close() {
    overlay.hidden = true;
    document.body.classList.remove("palette-open");
  }

  input.addEventListener("input", function () {
    var q = input.value.toLowerCase();
    filtered = items.filter(function (p) { return p[0].toLowerCase().indexOf(q) > -1; });
    cursor = 0;
    paint();
  });

  document.addEventListener("keydown", function (event) {
    var mod = event.metaKey || event.ctrlKey;
    if (mod && event.key.toLowerCase() === "k") {
      event.preventDefault();
      overlay.hidden ? open() : close();
      return;
    }
    if (overlay.hidden) return;
    if (event.key === "Escape") { event.preventDefault(); close(); }
    if (event.key === "ArrowDown") {
      event.preventDefault();
      cursor = Math.min(filtered.length - 1, cursor + 1);
      paint();
    }
    if (event.key === "ArrowUp") {
      event.preventDefault();
      cursor = Math.max(0, cursor - 1);
      paint();
    }
    if (event.key === "Enter" && filtered[cursor]) {
      event.preventDefault();
      go(filtered[cursor][1]);
    }
  });

  overlay.addEventListener("click", function (event) {
    if (event.target === overlay) close();
  });

  document.body.appendChild(overlay);
})();
