/* Theme boot — runs before paint so the page never flashes the wrong palette.
   No module so it executes synchronously from <head>. */
(function () {
  var root = document.documentElement;
  var meta = document.getElementById("meta-theme");

  var stored = null;
  try { stored = localStorage.getItem("keygate-theme"); } catch (error) { stored = null; }

  var theme = stored === "light" || stored === "dark"
    ? stored
    : (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");

  root.dataset.theme = theme;
  if (meta) meta.setAttribute("content", theme === "dark" ? "#0d0c12" : "#f7f7fb");

  root.classList.add("js");

  // If the app module never boots, reveal everything rather than leaving a blank page.
  window.setTimeout(function () {
    if (!window.__keygateReady) root.classList.remove("js");
  }, 3000);
})();
