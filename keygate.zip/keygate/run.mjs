// One command for the whole stack: bot + API, then the website.
// Both inherit .env from the project root, so WEB_SECRET stays in sync.
import { spawn } from "node:child_process";

const children = [];
function start(label, args) {
  const child = spawn(process.execPath, args, { stdio: "inherit", env: process.env });
  child.on("exit", (code) => {
    console.error(`[${label}] exited (${code}) - stopping the stack`);
    stop();
  });
  children.push(child);
}

function stop() {
  for (const child of children) if (!child.killed) child.kill();
  setTimeout(() => process.exit(0), 300);
}

start("bot", ["src/index.mjs"]);
setTimeout(() => start("web", ["web/server.mjs"]), 800);

for (const signal of ["SIGINT", "SIGTERM"]) process.on(signal, stop);
