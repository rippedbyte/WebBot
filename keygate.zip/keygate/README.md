# riP

Discord whitelist bot with a signed key API and a Roblox loader. Standalone: no third-party
auth service, no API tokens to buy, no external outage that can lock out a buyer, and no hosted script
delivery — you bring the loader, the bot only answers `KEY_VALID`.

One process. One dependency. Keys live locally, so a check never waits on a third-party
service; Luarmor and FlowAuth are optional mirror targets when you want their dashboards
to stay in sync.

```
riP/
├─ src/index.mjs        the whole server: store, crypto, service, API, slash commands
├─ loader/riP.lua   the distributable Roblox client
├─ tools/cli.mjs        offline key management, no Discord needed
├─ tests/smoke.test.mjs node:test suite over the service layer
├─ deploy/              nginx reverse proxy + systemd unit
├─ data/                JSON store lives here
├─ .env.example
├─ Dockerfile
└─ docker-compose.yml
```

## Quickstart

```bash
npm install
cp .env.example .env          # fill DISCORD_TOKEN, DISCORD_CLIENT_ID, generate both secrets
npm start
```

Generate secrets:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Set `DISCORD_GUILD_ID` while you are building — guild-scoped commands register instantly,
global ones can take up to an hour.

## In the server

1. `/config buyer-role role:@Buyer` and `/config manager-role role:@Staff`
2. `/setpanel channel:#access script_id:myhub loader:<lua body>`
3. `/admin create-keys count:25 days:30` → returns a `.txt` attachment
4. Ship `loader/riP.lua` with `base` and `script_id` set to yours

## Commands

| command | who | what |
|---|---|---|
| `/help` | everyone | how keys, activation and loading work |
| `/config show` | staff | current settings and counters |
| `/config hwid-days` | staff | device reset cooldown, 0 disables |
| `/config manager-role` | staff | role allowed to run staff commands |
| `/config buyer-role` | staff | role granted with an active key |
| `/config panel-text` | staff | custom line at the top of the panel |
| `/setpanel` | staff | posts the 5-button panel, registers the script and roles |
| `/setlogs` | staff | Discord webhook for bot events |
| `/whitelist` | staff | one key for one user, optional days and note |
| `/unwhitelist` | staff | delete a user's key |
| `/blacklist` | staff | ban a key, optional reason and days |
| `/force-hwidreset` | staff | clear the device binding, ignoring cooldown |
| `/compensate` | staff | add days to every key in the guild |
| `/user info` | staff | key, device, expiry, executions |
| `/admin create-keys` | staff | 1–500 keys, optional duration, note, script |
| `/admin revoke` | staff | delete by key |
| `/admin key-days` | staff | add or set 1–3650 days |
| `/admin mass-whitelist` | staff | key everyone holding a role |
| `/admin unbind` | staff | release a key so it can be redeemed again |
| `/admin lookup` | staff | find a key by user or by key |
| `/admin export` | staff | every key as a JSON attachment |
| `/admin purge` | staff | delete expired and banned keys |
| `/admin stats` | staff | counters |
| `/announce` | staff | titled embed, optional role ping |
| `/admin note` | staff | attach or clear a note on a key |
| `/giveaway start` | staff | prize, winners, minutes, key duration — posts an Enter button |
| `/giveaway end` | staff | draw immediately in this channel |
| `/giveaway reroll` | staff | redraw from the same entries |
| `/stats` | everyone | live counters |
| `/ticket panel` | staff | posts the Open a ticket button |
| `/ticket close` | owner, staff | close and delete the ticket |
| `/ticket add` | owner, staff | add someone to the ticket |
| `/ticket list` | staff | open tickets |
| `/config ticket-category` | staff | category new tickets land in |
| `/config auto-role` | staff | role given to every new member |
| `/key redeem` | buyer | bind a key to your account |
| `/key status` | buyer | state and time left |
| `/key copy` | buyer | show the key again |
| `/key script` | buyer | loader line with your key baked in |
| `/key reset-hwid` | buyer | move to a new device, cooldown applies |
| `/key role` | buyer | claim the buyer role |

Staff = guild owner, Administrator, an `OWNER_IDS` match, or the configured manager role.

## HTTP API

Base `PUBLIC_BASE_URL`. Every response carries `{ code, message, data?, time, signature }`
where `signature = HMAC-SHA256(API_SECRET, key + "|" + code + "|" + time)`.

| route | purpose |
|---|---|
| `GET /v1/health` | liveness |
| `GET /v1/sync` | Luarmor-shaped `{st, cf, nodes}` discovery |
| `GET /v1/check?key=&script_id=` | validate, bind device, count execution, return a ticket |
| `GET /v1/loader/:scriptId` | retired — returns 410, the bot does not host scripts |
| `POST /v1/resethwid` | admin only, `x-admin-secret` header |
| `GET /v1/metrics` | counters, uptime, key/guild/script totals |

Website bridge (requires `x-web-secret`, used only by `web/server.mjs`):

| route | purpose |
|---|---|
| `GET /v1/web/stats` | counters, masked recent checks, script list |
| `GET /v1/web/key?key=` | public row for one key |
| `GET /v1/web/history?key=` | last 10 checks for one key |
| `GET /v1/web/mykey?discordId=` | keys bound to a Discord account |
| `POST /v1/web/redeem` | bind a key to a Discord id |
| `POST /v1/web/resethwid` | self-serve device reset |
| `GET /v1/web/scripts` | registered script ids |
| `POST /v1/web/loader` | build the guard for a key — same output as `/key script` |

Device is read from `x-hwid` (or `clienthwid`, or `?hwid`). First successful check binds it.
A key bound to one script may omit `script_id`; the store fills it in.

```bash
curl -s "https://keys.example.com/v1/check?key=YOURKEY&script_id=myhub" \
  -H "x-hwid: $(uuidgen)"
```

```json
{
  "code": "KEY_VALID",
  "message": "The provided key is valid.",
  "data": { "auth_expire": 0, "note": "Not specified", "total_executions": 1 },
  "time": 1794007450,
  "signature": "a4d1…"
}
```

Codes: `KEY_VALID`, `KEY_EXPIRED`, `KEY_BANNED`, `KEY_HWID_LOCKED`, `KEY_INCORRECT`,
`KEY_INVALID`, `SCRIPT_ID_INCORRECT`, `RATE_LIMITED`.

Rate limit is 60 requests per minute per IP, in-process, 429 on overrun.

## Enforcement

The delivered loader is generated, not chosen. `/key script` hands each buyer:

```lua
--[[ riP guard — nothing below the payload line runs without a valid key ]]
local KEYGATE_KEY = "RIP_…"
local KEYGATE_SCRIPT = "hub"
local KEYGATE_BASE = "https://keys.example.com"
local KEYGATE_URL = "https://your-host/payload.lua"
… check via /v1/check …
if decoded.code ~= "KEY_VALID" then warn(...) return end
if KEYGATE_URL ~= "" then return loadstring(game:HttpGet(KEYGATE_URL))() end
```

the payload line sits after the guard and is the only thing after it, so the script cannot
execute without a `KEY_VALID` answer. `/setpanel` stores your hosted payload URL and never
copies it. `/v1/check` now refuses any request without a `script_id`, and refuses unknown
script ids outright.



## The check contract

The bot does not host or serve scripts. You publish your own loader, wherever you like, and
it calls one endpoint before running anything:

```lua
local key  = "YOURKEY"
local hwid = game:GetService("RbxAnalyticsService"):GetClientId()

local res  = game:HttpGet("https://keys.example.com/v1/check?key=" .. key
    .. "&script_id=myhub&hwid=" .. hwid)
local body = game:GetService("HttpService"):JSONDecode(res)

if body.code ~= "KEY_VALID" then
    return warn("riP: " .. body.message)
end

loadstring(game:HttpGet("https://your-own-host/your-script.lua"))()
```

Paste that loader into `/setpanel loader:` and **Get Script** hands each buyer their copy with
`script_key` already on the first line. Nothing about your payload passes through this bot.
## Running both processes

```bash
npm start      # bot + API on :8080
npm run web    # site on :3000, proxies /api/* to the bot
```

Both load `.env`, so `WEB_SECRET` must be **identical** in that file. On boot the
site calls `/v1/web/stats` and prints one of:

```
bridge ok - 412 keys, 3 scripts
WEB_SECRET mismatch - the bot rejected the site's secret
bot has no WEB_SECRET - set the same value in both .env files
```

The portal is self-serve: sign in with Discord (or paste a Discord id when OAuth is
not configured), activate a key, read status and activity, reset the device, and hit
**Build loader** to get the same guard `/key script` hands out in Discord. The landing
page reads live counters from `/api/stats`, including a masked feed of recent checks.

## Providers

None. This is a complete system on its own — there is no Luarmor or FlowAuth call,
no API token to buy, and no third party that can lock out your buyers. Checks read the
local store and nothing else, so the only outage that matters is yours.

Luarmor and FlowAuth were the design reference, not a dependency. Everything a check
needs lives in `data/keygate.json`.

## Operations

```bash
npm test                       # service-layer suite, no Discord needed
node tools/cli.mjs create --count 10 --days 30 --note beta
node tools/cli.mjs list
node tools/cli.mjs stats
```

**Stop the bot before using the CLI.** The process holds the store in memory and rewrites
the file on its next save, which would clobber CLI edits.

Docker:

```bash
cp .env.example .env
docker compose up -d --build
```

Bare metal: `deploy/keygate.service` for systemd, `deploy/nginx.conf` for TLS termination
and an edge rate limit that complements the in-process one.

## Security model

- Keys are 32 characters from a 62-symbol alphabet, drawn with rejection sampling so
  there is no modulo bias.
- **Keys are single-use.** Every key starts with `RIP_` followed by 32 letters, so a key is
  obvious in chat and easy to grep for. The first Discord account to activate a key owns it;
  anyone else is refused, and staff can release it with `/admin unbind`.
- Devices are stored as SHA-256 prefixes, never raw.
- Admin routes require a constant-time comparison against `ADMIN_SECRET`.
- Secrets never ride inside a slash command payload; nothing secret is stored at all
  beyond the two env secrets.
- The store is a single JSON file with atomic replace. It is not encrypted at rest: anyone
  with filesystem access has everything. Run it on a host you control, back up `data/`.

## Troubleshooting

| symptom | cause |
|---|---|
| commands never appear | `DISCORD_CLIENT_ID` wrong, or global registration still propagating — set `DISCORD_GUILD_ID` |
| `Invalid interaction` on startup | bot invited with the `applications.commands` scope missing |
| every check is `KEY_HWID_LOCKED` | client sends a fresh device id each run; derive it from something stable |
| `/v1/loader` returns `error(...)` | that Lua line is the 403 body; read the message in it |
| ticket rejected | `TICKET_TTL` elapsed between check and loader fetch, or the script id changed |
| edits lost after using the CLI | bot was running and rewrote the store |
| `signature` never matches | `API_SECRET` changed since the client cached it |
