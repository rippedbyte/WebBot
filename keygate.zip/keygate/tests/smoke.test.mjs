import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

// The module reads its config at import time, so point it at a scratch store first.
process.env.DB_PATH = join(mkdtempSync(join(tmpdir(), "keygate-")), "store.json");
process.env.API_SECRET = "test-secret-do-not-use";

const kg = await import("../src/index.mjs");

const GUILD = "guild-1";

test("generated keys are 32 chars, alphabet only, and unique", () => {
  const keys = kg.createKeys({ guildId: GUILD, count: 200 });
  assert.equal(keys.length, 200);
  assert.equal(new Set(keys).size, 200);
  for (const key of keys) assert.match(key, /^RIP_[a-zA-Z]{32}$/);
});

test("first check binds the device, second device is locked out", () => {
  const [key] = kg.createKeys({ guildId: GUILD, count: 1 });
  const first = kg.checkKey({ key, hwid: "device-a", ip: "1.1.1.1" });
  assert.equal(first.code, "KEY_VALID");
  assert.equal(first.data.total_executions, 1);

  const same = kg.checkKey({ key, hwid: "device-a" });
  assert.equal(same.code, "KEY_VALID");

  const other = kg.checkKey({ key, hwid: "device-b" });
  assert.equal(other.code, "KEY_HWID_LOCKED");

  assert.equal(kg.resetHwid(key, { force: true }).ok, true);
  const rebound = kg.checkKey({ key, hwid: "device-b" });
  assert.equal(rebound.code, "KEY_VALID");
});

test("expiry, ban and revoke each produce their own code", () => {
  const [key] = kg.createKeys({ guildId: GUILD, count: 1, days: 1 });
  assert.equal(kg.checkKey({ key, hwid: "d" }).code, "KEY_VALID");

  kg.changeDays(key, 1);
  assert.equal(kg.checkKey({ key, hwid: "d" }).code, "KEY_VALID");

  kg.changeDays(key, 1, "set");
  kg.data.keys[key].expires_at = kg.now() - 1;
  assert.equal(kg.checkKey({ key, hwid: "d" }).code, "KEY_EXPIRED");

  kg.changeDays(key, 30, "set");
  kg.ban(key, { reason: "chargeback" });
  assert.equal(kg.checkKey({ key, hwid: "d" }).code, "KEY_BANNED");

  assert.equal(kg.revoke(key), true);
  assert.equal(kg.checkKey({ key, hwid: "d" }).code, "KEY_INCORRECT");
});

test("unknown and malformed keys are rejected without throwing", () => {
  // 32 letters is a valid shape - legacy keys predate the RIP_ prefix - so an
  // unknown one is a mismatch, not a format error.
  assert.equal(kg.checkKey({ key: "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" }).code, "KEY_INCORRECT");
  assert.equal(kg.checkKey({ key: "" }).code, "KEY_INVALID");
  assert.equal(kg.checkKey({ key: "!!!not-a-key!!!" }).code, "KEY_INVALID");
  assert.equal(kg.checkKey({ key: undefined }).code, "KEY_INVALID");
  assert.equal(kg.checkKey({ key: "RIP_short" }).code, "KEY_INVALID");
});

test("script binding rejects a key used on another script", () => {
  const [key] = kg.createKeys({ guildId: GUILD, count: 1, scriptId: "script-a" });
  assert.equal(kg.checkKey({ key, scriptId: "script-b", hwid: "d" }).code, "SCRIPT_ID_INCORRECT");
  assert.equal(kg.checkKey({ key, scriptId: "script-a", hwid: "d" }).code, "KEY_VALID");
});

test("a key cannot be claimed by two Discord accounts", () => {
  const [key] = kg.createKeys({ guildId: GUILD, count: 1 });
  assert.equal(kg.bindDiscord(key, "user-1").ok, true);
  assert.equal(kg.bindDiscord(key, "user-2").ok, false);
  assert.equal(kg.bindDiscord(key, "user-1").ok, true);
  assert.equal(kg.keyForDiscord("user-1", GUILD).key, key);
});

test("signatures are deterministic and correctly sized", () => {
  assert.equal(kg.sign("payload"), kg.sign("payload"));
  assert.notEqual(kg.sign("payload"), kg.sign("payload "));
  assert.match(kg.sign("payload"), /^[0-9a-f]{64}$/);

  const result = kg.signed({ code: "KEY_VALID", message: "ok" }, "somekey");
  assert.match(result.signature, /^[0-9a-f]{64}$/);
  assert.equal(typeof result.time, "number");
});

test("tickets verify for their own script and nowhere else", () => {
  const [key] = kg.createKeys({ guildId: GUILD, count: 1, scriptId: "script-a" });
  const ticket = kg.issueTicket(key, "script-a");
  assert.equal(ticket.split(".").length, 3);

  const verified = kg.verifyTicket(ticket, "script-a");
  assert.equal(verified?.key, key);
  assert.equal(kg.verifyTicket(ticket, "script-b"), null);

  const [holder, expires, mac] = ticket.split(".");
  assert.equal(kg.verifyTicket(`${holder}.${Number(expires) - 1}.${mac}`, "script-a"), null);
  assert.equal(kg.verifyTicket(`${holder}.${expires}.${"0".repeat(64)}`, "script-a"), null);
  assert.equal(kg.verifyTicket("nope", "script-a"), null);
  assert.equal(kg.verifyTicket("", "script-a"), null);
});

test("an expired ticket dies even while the signature is intact", () => {
  const [key] = kg.createKeys({ guildId: GUILD, count: 1, scriptId: "script-a" });
  const stale = kg.now() - 5;
  const forged = `${key}.${stale}.${kg.sign(`${key}|script-a|${stale}`)}`;
  assert.equal(kg.verifyTicket(forged, "script-a"), null);
});

test("a banned key cannot redeem a previously issued ticket", () => {
  const [key] = kg.createKeys({ guildId: GUILD, count: 1, scriptId: "script-a" });
  const ticket = kg.issueTicket(key, "script-a");
  kg.ban(key, { reason: "test" });
  assert.equal(kg.verifyTicket(ticket, "script-a"), null);
});

test("identical HWIDs hash identically and differ across devices", () => {
  assert.equal(kg.hwidHash("abc"), kg.hwidHash("abc"));
  assert.notEqual(kg.hwidHash("abc"), kg.hwidHash("abd"));
  assert.match(kg.hwidHash("abc"), /^[0-9a-f]{32}$/);
});

test("a key can be redeemed exactly once", () => {
  const [key] = kg.createKeys({ guildId: GUILD, count: 1, scriptId: "script-a" });

  const first = kg.bindDiscord(key, "buyer-1");
  assert.equal(first.ok, true);
  assert.equal(first.already, false);
  assert.ok(kg.getKey(key).redeemed_at > 0);

  const repeat = kg.bindDiscord(key, "buyer-1");
  assert.equal(repeat.ok, true);
  assert.equal(repeat.already, true);

  const stolen = kg.bindDiscord(key, "buyer-2");
  assert.equal(stolen.ok, false);
  assert.match(stolen.error, /already redeemed/);

  // staff release, then the next account may claim it
  kg.getKey(key).discord_id = null;
  assert.equal(kg.bindDiscord(key, "buyer-2").ok, true);
});

test("expired and banned keys cannot be redeemed", () => {
  const [expired] = kg.createKeys({ guildId: GUILD, count: 1, days: 1 });
  kg.getKey(expired).expires_at = kg.now() - 1;
  assert.equal(kg.bindDiscord(expired, "buyer-1").ok, false);

  const [banned] = kg.createKeys({ guildId: GUILD, count: 1 });
  kg.ban(banned, { reason: "test" });
  assert.equal(kg.bindDiscord(banned, "buyer-1").ok, false);

  assert.equal(kg.bindDiscord("no-such-key", "buyer-1").ok, false);
});

test("giveaway draws winners without duplicates and issues prefixed keys", () => {
  const id = "gw_test";
  kg.data.giveaways[id] = {
    id, guild_id: GUILD, channel_id: "c1", message_id: "m1", prize: "beta access",
    winners: 2, days: 0, ended: false, ends_at: kg.now() + 60,
    entries: ["u1", "u2", "u3", "u3"], winner_ids: [], host_id: "staff",
  };

  const result = kg.drawGiveaway(id);
  assert.equal(result.winners.length, 2);
  assert.equal(new Set(result.winners).size, 2);
  assert.equal(result.keys.length, 2);
  for (const key of result.keys) assert.match(key, /^RIP_[a-zA-Z]{32}$/);
  assert.equal(kg.data.giveaways[id].ended, true);

  assert.equal(kg.drawGiveaway(id), null, "a drawn giveaway cannot be drawn twice");
});

test("a key with no entries draws nothing and issues no key", () => {
  const id = "gw_empty";
  kg.data.giveaways[id] = {
    id, guild_id: GUILD, channel_id: "c2", message_id: "m2", prize: "nothing",
    winners: 3, days: 0, ended: false, ends_at: kg.now() + 60,
    entries: [], winner_ids: [], host_id: "staff",
  };
  const result = kg.drawGiveaway(id);
  assert.deepEqual(result.winners, []);
});

test("the generated loader checks before it loads the payload", () => {
  const lua = kg.buildLoader({
    base: "https://keys.example.com",
    scriptId: "hub",
    scriptUrl: "https://cdn.example.com/payload.lua",
    key: "RIP_abcdefghijklmnopqrstuvwxyzABCDEF",
    body: "",
  });

  const guard = lua.indexOf("/v1/check");
  const payload = lua.indexOf("return chunk()");
  assert.ok(guard > 0, "check call present");
  assert.ok(payload > guard, "payload line comes after the check");
  assert.match(lua, /if decoded\.code ~= "KEY_VALID" then/);
  assert.ok(lua.includes("RIP_abcdefghijklmnopqrstuvwxyzABCDEF"));
  assert.match(lua, /for attempt = 1, 3 do/, "retries before giving up");
  assert.match(lua, /ripDevice\(\)/, "device fallback chain present");
  assert.match(lua, /UrlEncode\(ripDevice\(\)\)/, "hwid is url-encoded before it rides the query");
  assert.match(lua, /local chunk, err = loadstring\(payload\)/, "payload compile errors are reported");
});

test("legacy keys without the RIP_ prefix still validate", () => {
  const legacy = "rCzOZOzukRmWccAsCnaizxIgvvRCyGQz";
  kg.data.keys[legacy] = {
    key: legacy, guild_id: GUILD, script_id: null, discord_id: null, note: "legacy",
    created_at: kg.now(), expires_at: 0, hwid: null, hwid_reset_at: 0,
    banned: 0, ban_reason: null, executions: 0, redeemed_at: null,
  };

  assert.equal(kg.isKeyShape(legacy), true);
  assert.equal(kg.isKeyShape(`RIP_${legacy}`), true);
  assert.equal(kg.isKeyShape("short"), false);
  assert.equal(kg.checkKey({ key: legacy, hwid: "legacy-device" }).code, "KEY_VALID");
  assert.equal(kg.normalizeKey(`  ${legacy}  `), legacy);
  assert.equal(kg.checkKey({ key: `  ${legacy}  `, hwid: "legacy-device" }).code, "KEY_VALID");
});

test("a check records last seen and survives a missing counter", () => {
  const [key] = kg.createKeys({ guildId: GUILD, count: 1 });
  delete kg.data.keys[key].executions;
  const result = kg.checkKey({ key, hwid: "counter-device", ip: "203.0.113.9" });
  assert.equal(result.code, "KEY_VALID");
  assert.equal(result.data.total_executions, 1);
  assert.ok(kg.getKey(key).last_seen_at > 0);
  assert.match(kg.getKey(key).last_ip, /^[0-9a-f]{12}$/, "ip is stored as a digest");
  assert.equal(result.data.hwid_locked, true);
});

test("spoofed and expired tickets cannot issue access", () => {
  const [key] = kg.createKeys({ guildId: GUILD, count: 1, scriptId: "s1" });
  const ticket = kg.issueTicket(key, "s1");
  const [holder, expires, mac] = ticket.split(".");

  assert.equal(kg.verifyTicket(`${holder}.${expires}.${mac}`, "other"), null);
  assert.equal(kg.verifyTicket(`${holder}.${Number(expires) + 999}.${mac}`, "s1"), null);
  assert.equal(kg.verifyTicket(`${holder}.${expires}.${mac}.extra`, "s1"), null);
});

test("resets respect the cooldown and report when the next one is allowed", () => {
  const [key] = kg.createKeys({ guildId: GUILD, count: 1 });
  kg.checkKey({ key, hwid: "device-one" });

  const blocked = kg.resetHwid(key, { guildId: GUILD });
  assert.equal(blocked.ok, false);
  assert.ok(blocked.cooldownSeconds > 0);
  assert.ok(kg.cooldownRemaining(kg.getKey(key), GUILD) > 0);

  const forced = kg.resetHwid(key, { force: true, guildId: GUILD });
  assert.equal(forced.ok, true);
  assert.ok(forced.nextResetAt > kg.now());
});

test("the public row never leaks a raw account id", () => {
  const [key] = kg.createKeys({ guildId: GUILD, count: 1, discordId: "123456789012345678" });
  const row = kg.publicRow(kg.getKey(key));
  assert.equal(row.discordId.endsWith("5678"), true);
  assert.equal(row.discordId.includes("1234567890"), false);
  assert.equal(kg.maskId(""), null);
  assert.equal(kg.maskId(null), null);
});

test("audit records staff actions and caps the trail", () => {
  const before = kg.data.audit.length;
  const entry = kg.audit({ id: GUILD }, { id: "staff-1", tag: "staff#1" }, "test.action", "detail");
  assert.equal(entry.action, "test.action");
  assert.equal(entry.guild_id, GUILD);
  assert.equal(kg.data.audit.length, before + 1);
});

test("every slash command serialises and names are unique", () => {
  const payload = kg.definitions.map((command) => command.toJSON());
  const names = payload.map((c) => c.name);
  assert.equal(new Set(names).size, names.length, "duplicate command name");

  for (const command of payload) {
    assert.match(command.name, /^[\w-]{1,32}$/);
    assert.ok(command.description && command.description.length >= 1);
    assert.ok((command.options?.length ?? 0) <= 25, `${command.name} has too many options`);
    for (const option of command.options ?? []) {
      assert.match(option.name, /^[\w-]{1,32}$/);
      if (option.type === 1) {
        assert.ok(option.description, `${command.name}/${option.name} needs a description`);
        assert.ok((option.options?.length ?? 0) <= 25);
      }
    }
  }
  assert.ok(names.includes("key") && names.includes("admin") && names.includes("giveaway"));

  const keyCommand = payload.find((c) => c.name === "key");
  const keySubs = (keyCommand.options || []).map((o) => o.name);
  assert.ok(keySubs.includes("history"), "key history subcommand present");

  const adminCommand = payload.find((c) => c.name === "admin");
  const adminSubs = (adminCommand.options || []).map((o) => o.name);
  assert.ok(adminSubs.includes("audit"), "admin audit subcommand present");
});

test("stats count only the requested guild", () => {
  const local = kg.stats(GUILD);
  assert.ok(local.total >= 5);
  assert.ok(local.executions >= 3);
  assert.equal(kg.stats("never-seen-guild").total, 0);
});

test("a key resolves with or without its prefix", () => {
  const [prefixed] = kg.createKeys({ guildId: GUILD, count: 1 });
  const bare = prefixed.slice(4);

  assert.equal(kg.getKey(prefixed).key, prefixed);
  assert.equal(kg.getKey(bare).key, prefixed, "prefix may be dropped");
  assert.equal(kg.getKey(`RIP_${bare}`).key, prefixed, "prefix may be re-added");
  assert.equal(kg.getKey("  " + bare + "  ").key, prefixed, "whitespace trimmed");
  assert.equal(kg.getKey("nothing-here"), null);

  const legacy = "b".repeat(32);
  kg.data.keys[legacy] = {
    key: legacy, guild_id: GUILD, script_id: null, discord_id: null, note: null,
    created_at: kg.now(), expires_at: 0, hwid: null, hwid_reset_at: 0,
    banned: 0, ban_reason: null, executions: 0, redeemed_at: null,
  };
  assert.equal(kg.getKey(`RIP_${legacy}`).key, legacy, "legacy key accepts the prefix");
  assert.equal(kg.bindDiscord(`RIP_${legacy}`, "buyer-9").ok, true);
});

test("a read-only guild lookup never writes a row", () => {
  const before = Object.keys(kg.data.guilds).length;
  const ghost = kg.peekGuild("guild-that-does-not-exist");
  assert.equal(ghost.hwid_reset_days, 7);
  assert.equal(Object.keys(kg.data.guilds).length, before, "peekGuild does not create");
});

test("only real http(s) payload urls reach the loader", () => {
  assert.equal(kg.isHttpUrl("https://cdn.example.com/x.lua"), true);
  assert.equal(kg.isHttpUrl("http://cdn.example.com/x.lua"), true);
  assert.equal(kg.isHttpUrl(""), false);
  assert.equal(kg.isHttpUrl("javascript:alert(1)"), false);
  assert.equal(kg.isHttpUrl("file:///etc/passwd"), false);
  assert.equal(kg.isHttpUrl('https://x"><script>'), false);

  const lua = kg.buildLoader({
    base: "https://keys.example.com", scriptId: "hub",
    scriptUrl: "javascript:alert(1)", key: "RIP_x", body: "",
  });
  assert.match(lua, /local RIP_URL = ""/, "a bad url is dropped, not embedded");
});

test("activity keys are masked for the public dashboard", () => {
  assert.equal(kg.maskKey("RIP_abcdefghijklmnopqrstuvwxyzABCDEF"), "RIP_...CDEF");
  assert.equal(kg.maskKey("short"), "...");
  assert.equal(kg.maskKey(null), "...");
});
